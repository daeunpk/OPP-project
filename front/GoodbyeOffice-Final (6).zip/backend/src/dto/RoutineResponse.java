package dto;

import java.util.List;

public class RoutineResponse {
    public String category;
    public List<String> routines;
}