package service;

import model.User;

import java.util.HashMap;
import java.util.Map;

public class UserService {

    private Map<String, String> users = new HashMap<>();

    public boolean signUp(String username, String password) {
        if (users.containsKey(username)) return false;
        users.put(username, password);
        return true;
    }

    public boolean login(String username, String password) {
        return password.equals(users.get(username));
    }

    public User getUser(String username) {
        if (!users.containsKey(username)) return null;
        User user = new User();
        user.username = username;
        user.password = users.get(username);
        return user;
    }
}