package service;

import java.time.LocalTime;

public class TimeEstimateService {

    public String estimateLeaveTime(String mood, String energy, String social) {
        // 단순 논리 예시
        if ("tired".equalsIgnoreCase(mood) || "low".equalsIgnoreCase(energy)) {
            return "18:00";
        } else if ("social".equalsIgnoreCase(social)) {
            return "19:00";
        } else {
            return "18:30";
        }
    }
}