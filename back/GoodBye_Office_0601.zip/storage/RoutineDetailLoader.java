package storage;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.FileReader;
import java.lang.reflect.Type;
import java.util.*;

public class RoutineDetailLoader {

    public static Map<String, List<String>> loadDetails() {
        try (FileReader reader = new FileReader("data/routine_details.json")) {
            Gson gson = new Gson();
            Type type = new TypeToken<Map<String, List<String>>>() {}.getType();
            return gson.fromJson(reader, type);
        } catch (Exception e) {
            e.printStackTrace();
            return new HashMap<>();
        }
    }
}
