package storage;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import model.RoutineCard;

import java.io.FileReader;
import java.lang.reflect.Type;
import java.util.List;
import java.util.Map;

public class RoutineLoader {
    public static List<RoutineCard> loadRoutines() {
        try {
            Gson gson = new Gson();
            FileReader reader = new FileReader("data/routine_categories.json");

            // 전체 JSON 객체에서 "routines" 배열 추출
            Type mapType = new TypeToken<Map<String, List<RoutineCard>>>() {}.getType();
            Map<String, List<RoutineCard>> map = gson.fromJson(reader, mapType);

            return map.get("routines");
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
