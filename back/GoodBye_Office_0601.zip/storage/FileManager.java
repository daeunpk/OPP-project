package storage;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import model.User;

import java.io.*;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class FileManager {
    private static final String USER_FILE = "data/users.json";
    private static final Gson gson = new Gson();

    // 사용자 리스트 저장
    public static void saveUsers(List<User> users) {
        try (Writer writer = new FileWriter(USER_FILE)) {
            gson.toJson(users, writer);
        } catch (IOException e) {
            System.out.println("사용자 저장 실패: " + e.getMessage());
        }
    }

    // 사용자 리스트 불러오기
    public static List<User> loadUsers() {
        File file = new File(USER_FILE);
        if (!file.exists()) {
            return new ArrayList<>();
        }

        try (Reader reader = new FileReader(USER_FILE)) {
            Type userListType = new TypeToken<ArrayList<User>>() {}.getType();
            return gson.fromJson(reader, userListType);
        } catch (IOException e) {
            System.out.println("사용자 불러오기 실패: " + e.getMessage());
            return new ArrayList<>();
        }
    }
}
