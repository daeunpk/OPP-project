package storage;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.FileReader;
import java.lang.reflect.Type;
import java.util.*;

public class RoutineCategoryLoader {
    private static final String CATEGORY_FILE_PATH = "data/routine_categories.json";

    // ✅ 기존 JSON 구조로 그대로 불러오는 메서드 (안 쓰일 수 있음)
    public static Map<String, List<Map<String, Object>>> loadRaw() {
        try (FileReader reader = new FileReader(CATEGORY_FILE_PATH)) {
            Gson gson = new Gson();
            Type type = new TypeToken<Map<String, List<Map<String, Object>>>>() {}.getType();
            return gson.fromJson(reader, type);
        } catch (Exception e) {
            e.printStackTrace();
            return new HashMap<>();
        }
    }

    // ✅ 우리가 진짜로 쓸 메서드: JSON 구조를 변환해서 가져오는 메서드
    public static Map<String, Map<String, List<String>>> loadCategories() {
        Map<String, List<Map<String, Object>>> raw = loadRaw();
        Map<String, Map<String, List<String>>> result = new HashMap<>();

        for (String part : raw.keySet()) {
            Map<String, List<String>> categoryMap = new HashMap<>();
            for (Map<String, Object> entry : raw.get(part)) {
                String category = (String) entry.get("category");
                List<String> tags = (List<String>) entry.get("tags");
                categoryMap.put(category, tags);
            }
            result.put(part, categoryMap);
        }

        return result;
    }
}
