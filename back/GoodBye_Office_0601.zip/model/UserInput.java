package model;

public class UserInput {
    private String mood;         // 기분 (ex: "매우 좋음", "좋음", "보통", "나쁨")
    private int energy;          // 에너지 (1~5)
    private String socialPref;   // 사람과 함께하고 싶은지 ("혼자", "함께")
    private String endOfDayMode; // 종료 시간 방식 ("자동 예측", "직접 입력")
    private String endTime;      // 직접 입력한 퇴근 시간 (예: "20:30")

    public UserInput(String mood, int energy, String socialPref, String endOfDayMode, String endTime) {
        this.mood = mood;
        this.energy = energy;
        this.socialPref = socialPref;
        this.endOfDayMode = endOfDayMode;
        this.endTime = endTime;
    }

    // Getter & Setter
    public String getMood() { return mood; }
    public void setMood(String mood) { this.mood = mood; }

    public int getEnergy() { return energy; }
    public void setEnergy(int energy) { this.energy = energy; }

    public String getSocialPref() { return socialPref; }
    public void setSocialPref(String socialPref) { this.socialPref = socialPref; }

    public String getEndOfDayMode() { return endOfDayMode; }
    public void setEndOfDayMode(String endOfDayMode) { this.endOfDayMode = endOfDayMode; }

    public String getEndTime() { return endTime; }
    public void setEndTime(String endTime) { this.endTime = endTime; }
}
