package model;

public class RoutineStep {
    private String category; // 예: 저녁, 활동, 마무리
    private String content;  // 예: 국밥, 산책, 명상

    public RoutineStep(String category, String content) {
        this.category = category;
        this.content = content;
    }

    public String getCategory() { return category; }
    public String getContent() { return content; }

    public void setCategory(String category) { this.category = category; }
    public void setContent(String content) { this.content = content; }
}
