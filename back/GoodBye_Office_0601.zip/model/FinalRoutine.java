package model;

import model.RoutineCard;
import java.util.List;
import java.util.Map;

public class FinalRoutine {
    private String userId;
    private String date;
    private String title;
    private Map<String, String> categories;
    private Map<String, List<String>> details;

    public FinalRoutine(String userId, String date, String title,
                        Map<String, String> categories,
                        Map<String, List<String>> details) {
        this.userId = userId;
        this.date = date;
        this.title = title;
        this.categories = categories;
        this.details = details;
    }

    public String getUserId() { return userId; }
    public String getDate() { return date; }
    public String getTitle() { return title; }
    public Map<String, String> getCategories() { return categories; }
    public Map<String, List<String>> getDetails() { return details; }
}
