package model;

public class RoutineCard {
    private String title;
    private String dinner;
    private String activity;
    private String closing;

    public RoutineCard(String title, String dinner, String activity, String closing) {
        this.title = title;
        this.dinner = dinner;
        this.activity = activity;
        this.closing = closing;
    }

    public String getTitle() {
        return title;
    }

    public String getDinner() {
        return dinner;
    }

    public String getActivity() {
        return activity;
    }

    public String getClosing() {
        return closing;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setDinner(String dinner) {
        this.dinner = dinner;
    }

    public void setActivity(String activity) {
        this.activity = activity;
    }

    public void setClosing(String closing) {
        this.closing = closing;
    }
}
