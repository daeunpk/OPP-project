package model;

public class User {
    private String name;       // 이름
    private String employeeId; // 사번
    private String phone;      // 전화번호
    private String email;      // 이메일
    private String lastLogin;  // 최근 접속일 ("YYYY-MM-DD")

    // 생성자
    public User(String name, String employeeId, String phone, String email, String lastLogin) {
        this.name = name;
        this.employeeId = employeeId;
        this.phone = phone;
        this.email = email;
        this.lastLogin = lastLogin;
    }

    // Getter & Setter
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEmployeeId() { return employeeId; }
    public void setEmployeeId(String employeeId) { this.employeeId = employeeId; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getLastLogin() { return lastLogin; }
    public void setLastLogin(String lastLogin) { this.lastLogin = lastLogin; }

    public String getId() { return employeeId; }
}
