package model;

import java.util.List;

public class RoutineCategory {
    private String category;
    private List<String> tags;

    public String getCategory() {
        return category;
    }

    public List<String> getTags() {
        return tags;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setTags(List<String> tags) {
        this.tags = tags;
    }
}
