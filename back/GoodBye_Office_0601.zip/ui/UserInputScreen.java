package ui;

import model.UserInput;

import java.util.Scanner;

public class UserInputScreen {
    private Scanner scanner;

    public UserInputScreen() {
        scanner = new Scanner(System.in);
    }

    public UserInput getUserInput() {
        System.out.println("\n===== 오늘 하루 상태 입력 =====");

        // 기분
        System.out.println("오늘 기분은 어떤가요?");
        System.out.println("[1] 😊 매우 좋음");
        System.out.println("[2] 🙂 좋음");
        System.out.println("[3] 😐 보통");
        System.out.println("[4] 😣 나쁨");
        System.out.print("선택: ");
        int moodChoice = scanner.nextInt();
        scanner.nextLine(); // 엔터 제거

        String mood = switch (moodChoice) {
            case 1 -> "매우 좋음";
            case 2 -> "좋음";
            case 3 -> "보통";
            case 4 -> "나쁨";
            default -> "보통"; // 기본값
        };

        // 활력
        System.out.print("남아 있는 에너지를 1~5 사이로 입력해주세요 (1 = 매우 낮음, 5 = 매우 높음): ");
        int energy = scanner.nextInt();
        scanner.nextLine();

        // 사람과 함께하고 싶은지
        System.out.println("퇴근 후 어떻게 보내고 싶나요?");
        System.out.println("[1] 혼자 있고 싶어요");
        System.out.println("[2] 사람을 만나고 싶어요");
        System.out.print("선택: ");
        int socialChoice = scanner.nextInt();
        scanner.nextLine();

        String socialPref = (socialChoice == 1) ? "혼자" : "함께";

        // 퇴근 시간 입력 방식
        System.out.println("오늘의 퇴근 시간을 어떻게 설정할까요?");
        System.out.println("[1] 자동 예측할게요");
        System.out.println("[2] 직접 입력할게요");
        System.out.print("선택: ");
        int endChoice = scanner.nextInt();
        scanner.nextLine();

        String endMode = (endChoice == 1) ? "자동 예측" : "직접 입력";
        String endTime = "";

        if (endMode.equals("직접 입력")) {
            System.out.print("퇴근 시간을 HH:MM 형식으로 입력해주세요 (예: 20:30): ");
            endTime = scanner.nextLine();
        }

        return new UserInput(mood, energy, socialPref, endMode, endTime);
    }
}
