package ui;

import model.FinalRoutine;
import model.RoutineCard;
import model.User;
import model.UserInput;
import service.RoutineDetailRecommender;
import service.RoutineRecommender;
import service.RoutineSaver;
import service.TimePredictor;
import service.UserService;

import java.time.LocalDate;
import java.util.*;

public class MainMenu {
    private UserService userService;
    private Scanner scanner;

    public MainMenu() {
        userService = new UserService();
        scanner = new Scanner(System.in);
    }

    public void start() {
        System.out.println("===== 굿바이 오피스에 오신 걸 환영합니다 =====");

        while (true) {
            System.out.println("\n[1] 회원가입");
            System.out.println("[2] 로그인");
            System.out.println("[0] 종료");
            System.out.print("메뉴 선택: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // 엔터 제거

            if (choice == 1) {
                register();
            } else if (choice == 2) {
                login();
            } else if (choice == 0) {
                System.out.println("프로그램을 종료합니다.");
                break;
            } else {
                System.out.println("잘못된 입력입니다.");
            }
        }
    }

    private void register() {
        System.out.print("이름: ");
        String name = scanner.nextLine();
        System.out.print("사번: ");
        String id = scanner.nextLine();
        System.out.print("전화번호: ");
        String phone = scanner.nextLine();
        System.out.print("이메일: ");
        String email = scanner.nextLine();
        String today = "2025-06-01"; // 날짜 임시 고정

        User user = new User(name, id, phone, email, today);
        boolean success = userService.register(user);

        if (success) {
            System.out.println("✅ 회원가입 성공!");
        } else {
            System.out.println("❌ 이미 등록된 사번입니다.");
        }
    }

    private void login() {
        System.out.print("사번을 입력하세요: ");
        String id = scanner.nextLine();

        User user = userService.login(id);
        if (user != null) {
            System.out.println("✅ 로그인 성공! 환영합니다, " + user.getName() + "님.");

            // ✅ 사용자 상태 입력
            UserInputScreen inputScreen = new UserInputScreen();
            UserInput input = inputScreen.getUserInput();

            // ✅ 퇴근 시간 예측 or 직접 입력
            String finalLeaveTime;
            if (input.getEndOfDayMode().equals("자동 예측")) {
                TimePredictor predictor = new TimePredictor();
                finalLeaveTime = predictor.predictLeaveTime("18:00");
            } else {
                finalLeaveTime = input.getEndTime();
            }

            System.out.println("🌙 예상 퇴근 시간: " + finalLeaveTime);

            // ✅ 루틴 3개 추천
            RoutineRecommender recommender = new RoutineRecommender();
            List<Map<String, String>> candidates = recommender.recommendMultiple(input, finalLeaveTime);

            // ✅ 루틴 3개 출력
            System.out.println("\n📌 추천 루틴 3가지:");
            for (int i = 0; i < candidates.size(); i++) {
                Map<String, String> c = candidates.get(i);
                System.out.println("[" + (i + 1) + "] " +
                        c.get("dinner") + " + " + c.get("activity") + " + " + c.get("closing"));
            }

            // ✅ 사용자 루틴 선택
            System.out.print("▶ 사용할 루틴 번호 선택 (1~3): ");
            int selected = scanner.nextInt();
            scanner.nextLine(); // 엔터 제거

            if (selected < 1 || selected > candidates.size()) {
                System.out.println("❌ 잘못된 선택입니다.");
                return;
            }

            Map<String, String> selectedRoutine = candidates.get(selected - 1);

            // ✅ 세부 항목 추천
            Map<String, List<String>> detailMap = RoutineDetailRecommender.recommendDetails(selectedRoutine);

            // ✅ 사용자 선택한 세부 항목 저장
            Map<String, String> selectedDetails = new LinkedHashMap<>();

            for (String part : List.of("dinner", "activity", "closing")) {
                List<String> options = detailMap.get(part);
                System.out.println("🔹 " + part + " 세부 추천:");
                for (int i = 0; i < options.size(); i++) {
                    System.out.println((i + 1) + ". " + options.get(i));
                }

                System.out.print("▶ " + part + "에서 선택 (1~" + options.size() + "): ");
                int choice = scanner.nextInt();
                scanner.nextLine(); // 엔터 제거
                selectedDetails.put(part, options.get(choice - 1));
            }

            // ✅ 최종 루틴 생성
            FinalRoutine finalRoutine = new FinalRoutine(
                user.getId(),
                LocalDate.now().toString(),
                "나의 퇴근 루틴",
                selectedRoutine,
                Map.of(
                    "dinner", List.of(selectedDetails.get("dinner")),
                    "activity", List.of(selectedDetails.get("activity")),
                    "closing", List.of(selectedDetails.get("closing"))
                )
            );

            // ✅ 저장 방식 선택
            System.out.println("\n💾 저장 방식을 선택하세요:");
            System.out.println("[1] JSON 형식으로 저장");
            System.out.println("[2] 텍스트 형식으로 저장");
            System.out.print("선택: ");
            int saveChoice = scanner.nextInt();
            scanner.nextLine();

            if (saveChoice == 1) {
                RoutineSaver.saveAsJson(finalRoutine);
            } else if (saveChoice == 2) {
                RoutineSaver.saveAsTxt(finalRoutine);
            } else {
                System.out.println("❌ 잘못된 선택입니다. 저장하지 않습니다.");
            }

        } else {
            System.out.println("❌ 사번이 일치하지 않습니다.");
        }
    }
}
