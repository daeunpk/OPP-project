// RoutineDetailRecommender.java
package service;

import storage.RoutineDetailLoader;

import java.util.*;

public class RoutineDetailRecommender {

    public static Map<String, List<String>> recommendDetails(Map<String, String> categoryMap) {
        Map<String, List<String>> allDetails = RoutineDetailLoader.loadDetails();
        Map<String, List<String>> result = new LinkedHashMap<>();

        for (Map.Entry<String, String> entry : categoryMap.entrySet()) {
            String part = entry.getKey();           // dinner, activity, closing
            String category = entry.getValue();     // 예: 매운 음식, 실내 활동 등

            List<String> options = allDetails.getOrDefault(category, List.of("(준비된 항목 없음)"));
            List<String> top3 = options.size() > 3 ? options.subList(0, 3) : new ArrayList<>(options);
            result.put(part, top3);
        }

        return result;
    }

    // 디버깅 또는 콘솔 출력용 메서드
    public static void printRecommendedDetails(Map<String, List<String>> detailMap) {
        for (String part : List.of("dinner", "activity", "closing")) {
            System.out.println("🔹 " + part + " 세부 추천:");
            List<String> items = detailMap.getOrDefault(part, List.of("(추천 없음)"));
            for (String item : items) {
                System.out.println(" - " + item);
            }
            System.out.println();
        }
    }
}
