package service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import model.FinalRoutine;

import java.io.FileWriter;
import java.io.IOException;

public class RoutineSaver {

    public static void saveAsJson(FinalRoutine routine) {
        try (FileWriter writer = new FileWriter("final_routine.json")) {
            Gson gson = new GsonBuilder().setPrettyPrinting().create();
            gson.toJson(routine, writer);
            System.out.println("✅ 루틴이 JSON 형식으로 저장되었습니다!");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void saveAsTxt(FinalRoutine routine) {
        try (FileWriter writer = new FileWriter("final_routine.txt")) {
            writer.write("== 나의 퇴근 루틴 ==\n");
            writer.write("날짜: " + routine.getDate() + "\n\n");

            writer.write("[루틴 구성]\n");
            for (String part : routine.getCategories().keySet()) {
                writer.write("- " + part + ": " + routine.getCategories().get(part) + "\n");
            }

            writer.write("\n[세부 항목]\n");
            for (String part : routine.getDetails().keySet()) {
                for (String item : routine.getDetails().get(part)) {
                    writer.write("- " + part + ": " + item + "\n");
                }
            }

            System.out.println("✅ 루틴이 텍스트 형식으로 저장되었습니다!");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
