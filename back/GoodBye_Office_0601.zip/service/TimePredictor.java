package service;

import java.util.Scanner;

public class TimePredictor {
    private Scanner scanner;

    public TimePredictor() {
        scanner = new Scanner(System.in);
    }

    public String predictLeaveTime(String currentTime) {
        System.out.println("\n===== 퇴근 시간 예측을 위한 추가 질문 =====");

        // 1. 업무 개수
        System.out.print("남아 있는 업무는 몇 건인가요? ");
        int taskCount = scanner.nextInt();
        scanner.nextLine();

        // 2. 업무 강도
        System.out.print("업무 강도를 0~10 사이로 입력해주세요 (5 = 보통): ");
        int taskLevel = scanner.nextInt();
        scanner.nextLine();

        // 3. 회의 여부
        System.out.print("남은 회의가 있나요? (1 = 있음, 0 = 없음): ");
        int hasMeeting = scanner.nextInt();
        scanner.nextLine();

        int meetingCount = 0;
        if (hasMeeting == 1) {
            System.out.print("남은 회의 개수는 몇 개인가요? ");
            meetingCount = scanner.nextInt();
            scanner.nextLine();
        }

        // 4. 상사 기분
        System.out.println("오늘 상사의 기분은 어떤가요?");
        System.out.println("[1] 😀 매우 좋음");
        System.out.println("[2] 🙂 좋음");
        System.out.println("[3] 😐 보통");
        System.out.println("[4] 😠 나쁨");
        System.out.print("선택: ");
        int bossMood = scanner.nextInt();
        scanner.nextLine();

        // =========================================
        // 퇴근 시간 계산 로직
        int totalMinutes = 0;
        totalMinutes += taskCount * 30;
        totalMinutes += meetingCount * 30;

        // 업무 강도 비율 보정
        double ratio = 1.0 + ((taskLevel - 5) * 0.05); // 5 기준 ±5%씩
        totalMinutes = (int) (totalMinutes * ratio);

        // 상사 기분 보정
        switch (bossMood) {
            case 1 -> totalMinutes += 0;
            case 2 -> totalMinutes += 10;
            case 3 -> totalMinutes += 15;
            case 4 -> totalMinutes += 20;
        }

        // 현재 시간 기준 퇴근 시간 계산
        String[] parts = currentTime.split(":");
        int hour = Integer.parseInt(parts[0]);
        int minute = Integer.parseInt(parts[1]);

        int newMinutes = hour * 60 + minute + totalMinutes;
        int finalHour = newMinutes / 60;
        int finalMinute = newMinutes % 60;

        return String.format("%02d:%02d", finalHour, finalMinute);
    }
}
