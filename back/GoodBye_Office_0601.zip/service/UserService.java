package service;

import model.User;
import storage.FileManager;

import java.util.ArrayList;
import java.util.List;

public class UserService {
    private List<User> userList;

    public UserService() {
        userList = FileManager.loadUsers(); // 파일에서 사용자 불러오기
    }

    // 회원가입
    public boolean register(User newUser) {
        for (User user : userList) {
            if (user.getEmployeeId().equals(newUser.getEmployeeId())) {
                return false; // 중복 사번
            }
        }
        userList.add(newUser);
        FileManager.saveUsers(userList); // 파일로 저장
        return true;
    }

    // 로그인
    public User login(String employeeId) {
        for (User user : userList) {
            if (user.getEmployeeId().equals(employeeId)) {
                return user;
            }
        }
        return null; // 로그인 실패
    }

    // 전체 사용자 목록 가져오기
    public List<User> getAllUsers() {
        return userList;
    }

    // 사용자 탈퇴
    public boolean deleteUser(String employeeId) {
        for (User user : userList) {
            if (user.getEmployeeId().equals(employeeId)) {
                userList.remove(user);
                FileManager.saveUsers(userList);
                return true;
            }
        }
        return false;
    }
}
