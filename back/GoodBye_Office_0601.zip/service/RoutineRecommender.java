// RoutineRecommender.java
package service;

import model.UserInput;
import storage.RoutineCategoryLoader;

import java.util.*;

public class RoutineRecommender {

    private Map<String, Map<String, List<String>>> categoryMap;

    public RoutineRecommender() {
        this.categoryMap = RoutineCategoryLoader.loadCategories(); // ✅ 타입 통일
    }

    public Map<String, String> recommend(UserInput input, String leaveTime) {
        Map<String, String> result = new HashMap<>();

        String mood = input.getMood(); // 예: "좋음"
        String energyLevel = getEnergyLevel(input.getEnergy()); // 예: "중간"
        String social = input.getSocialPref(); // 예: "혼자" 또는 "사람 만남"
        String timeAmount = getTimeAmount(leaveTime); // 예: "시간 중간"

        // 각 파트별 best 매칭
        result.put("dinner", matchBest("dinner", List.of("기분 " + mood, "활력 " + energyLevel)));
        result.put("activity", matchBest("activity", List.of(social, "활력 " + energyLevel, timeAmount)));
        result.put("final", matchBest("final", List.of("기분 " + mood, "활력 " + energyLevel)));

        return result;
    }

    private String matchBest(String type, List<String> tags) {
        Map<String, List<String>> categorySet = categoryMap.getOrDefault(type, new HashMap<>());

        String best = "기본 루틴";
        int maxScore = -1;

        for (String category : categorySet.keySet()) {
            List<String> categoryTags = categorySet.get(category);
            int score = 0;
            for (String tag : tags) {
                if (categoryTags.contains(tag)) score++;
            }
            if (score > maxScore) {
                best = category;
                maxScore = score;
            }
        }

        return best;
    }

    private String getEnergyLevel(int level) {
        if (level <= 2) return "낮음";
        else if (level <= 4) return "중간";
        else return "높음";
    }

    private String getTimeAmount(String leaveTime) {
        try {
            String[] parts = leaveTime.split(":");
            int hour = Integer.parseInt(parts[0]);

            if (hour < 18) return "시간 많음";
            else if (hour <= 19) return "시간 중간";
            else return "시간 적음";
        } catch (Exception e) {
            return "시간 중간";
        }
    }

    public List<Map<String, String>> recommendMultiple(UserInput input, String leaveTime) {
        Map<String, Map<String, List<String>>> allCategories = RoutineCategoryLoader.loadCategories();
        List<Map<String, String>> results = new ArrayList<>();

        // 최대 3개의 루틴 추천
        for (int i = 0; i < 3; i++) {
            Map<String, String> categoryMap = new LinkedHashMap<>();

            // dinner 추천
            String dinner = findBestCategory(allCategories.get("dinner"), input.getMood(), input.getEnergy(), null);
            categoryMap.put("dinner", dinner);

            // activity 추천
            String timeTag = getTimeTag(leaveTime);
            String activity = findBestCategory(allCategories.get("activity"), input.getSocialPref(), input.getEnergy(), timeTag);
            categoryMap.put("activity", activity);

            // closing 추천
            String closing = findBestCategory(allCategories.get("final"), input.getMood(), input.getEnergy(), null);
            categoryMap.put("closing", closing);

            results.add(categoryMap);
        }

        return results;
    }

    private String getTimeTag(String time) {
        // 예: 18:00 이전 → "시간 적음", 18:00~20:00 → "시간 중간", 이후 → "시간 많음"
        try {
            String[] parts = time.split(":");
            int hour = Integer.parseInt(parts[0]);

            if (hour < 18) return "시간 적음";
            else if (hour <= 20) return "시간 중간";
            else return "시간 많음";
        } catch (Exception e) {
            return "시간 중간";
        }
    }

    private String findBestCategory(Map<String, List<String>> candidates,
                                    String tag1, int energy, String optionalTag) {
        String energyTag = getEnergyTag(energy);
        int maxScore = -1;
        String best = "(추천 없음)";

        for (Map.Entry<String, List<String>> entry : candidates.entrySet()) {
            int score = 0;
            List<String> tags = entry.getValue();

            if (tags.contains(tag1)) score += 3;
            if (tags.contains(energyTag)) score += 2;
            if (optionalTag != null && tags.contains(optionalTag)) score += 1;

            if (score > maxScore) {
                maxScore = score;
                best = entry.getKey();
            }
        }

        return best;
    }

    private String getEnergyTag(int energy) {
        if (energy <= 2) return "활력 낮음";
        else if (energy <= 4) return "활력 중간";
        else return "활력 높음";
    }
}
