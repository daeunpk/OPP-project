import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.io.FileReader;
import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class RoutineManagementPage extends JFrame {

    public RoutineManagementPage() {
        setTitle("루틴 관리");
        setSize(1280, 800); // 13인치 기준
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(new Color(13, 39, 84));

        JPanel topBar = new JPanel(null);
        topBar.setBounds(0, 0, 1280, 80);
        topBar.setBackground(new Color(13, 39, 84));
        add(topBar);

        JButton backButton = new JButton("이전");
        backButton.setFont(new Font("SansSerif", Font.BOLD, 18));
        backButton.setBounds(20, 20, 50, 40);
        topBar.add(backButton);
        backButton.addActionListener(e -> {
            new AdminDashboardPage().setVisible(true);
            dispose();
        });

        JLabel titleLabel = new JLabel("루틴 관리", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Pretendard", Font.BOLD, 28));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBounds(0, 20, 1280, 40);
        topBar.add(titleLabel);

        JLabel dateLabel = new JLabel("2025년 5월 19일", SwingConstants.RIGHT);
        dateLabel.setForeground(Color.WHITE);
        dateLabel.setFont(new Font("Pretendard", Font.PLAIN, 16));
        dateLabel.setBounds(1000, 20, 200, 40);
        topBar.add(dateLabel);

        JButton saveButton = new JButton("저장");
        saveButton.setBounds(1200, 20, 30, 30);
        topBar.add(saveButton);

        JButton homeButton = new JButton("홈");
        homeButton.setBounds(1240, 20, 30, 30);
        topBar.add(homeButton);
        homeButton.addActionListener(e -> {
            new MainPage().setVisible(true);
            dispose();
        });

        String[] columns = {"루틴 이름", "시작 시간", "카테고리", "세부 내용", "관리"};
        Object[][] data = loadRoutineData("storage/routine_data.json");

        DefaultTableModel model = new DefaultTableModel(data, columns) {
            public boolean isCellEditable(int row, int column) {
                return column == 4;
            }
        };

        JTable table = new JTable(model);
        table.setRowHeight(40);
        table.setFont(new Font("Pretendard", Font.PLAIN, 16));
        table.setForeground(Color.WHITE);
        table.setBackground(new Color(13, 39, 84));
        table.setGridColor(Color.WHITE);
        table.setShowHorizontalLines(true);
        table.setShowVerticalLines(false);

        for (int i = 0; i < table.getColumnCount(); i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(new CenterRenderer());
        }

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Pretendard", Font.BOLD, 16));
        header.setBackground(new Color(13, 39, 84));
        header.setForeground(Color.WHITE);

        table.getColumn("관리").setCellRenderer(new ButtonRenderer());
        table.getColumn("관리").setCellEditor(new ButtonEditor(new JCheckBox(), table));

        JScrollPane scrollPane = new JScrollPane(table);
        int tableHeight = table.getRowHeight() * table.getRowCount() + header.getPreferredSize().height;
        int reducedTableHeight = Math.min(tableHeight, 550);
        scrollPane.setBounds(100, 120, 1080, reducedTableHeight);
        add(scrollPane);

        JPanel bottomSpacer = new JPanel();
        bottomSpacer.setBackground(new Color(13, 39, 84));
        bottomSpacer.setBounds(100, 130 + reducedTableHeight, 1080, 60);
        add(bottomSpacer);

        setVisible(true);
    }

    private Object[][] loadRoutineData(String filePath) {
        List<Map<String, String>> routineList = new ArrayList<>();
        try {
            Gson gson = new Gson();
            FileReader reader = new FileReader(filePath);
            java.lang.reflect.Type type = new TypeToken<List<Map<String, String>>>() {}.getType();
            routineList = gson.fromJson(reader, type);
            reader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        Object[][] data = new Object[routineList.size()][5];
        for (int i = 0; i < routineList.size(); i++) {
            Map<String, String> r = routineList.get(i);
            data[i][0] = r.get("name");
            data[i][1] = r.get("time");
            data[i][2] = r.get("category");
            data[i][3] = r.get("details");
            data[i][4] = "삭제";
        }
        return data;
    }

    class CenterRenderer extends DefaultTableCellRenderer {
        public CenterRenderer() {
            setHorizontalAlignment(SwingConstants.CENTER);
        }
    }

    class ButtonRenderer extends JButton implements javax.swing.table.TableCellRenderer {
        public ButtonRenderer() {
            setOpaque(true);
            setText("삭제");
            setBackground(Color.WHITE);
            setForeground(new Color(13, 39, 84));
            setFont(new Font("Pretendard", Font.BOLD, 14));
        }

        public Component getTableCellRendererComponent(JTable table, Object value,
                                                       boolean isSelected, boolean hasFocus, int row, int column) {
            return this;
        }
    }

    class ButtonEditor extends DefaultCellEditor {
        private JButton button;
        private boolean clicked;
        private int selectedRow;
        private JTable table;

        public ButtonEditor(JCheckBox checkBox, JTable table) {
            super(checkBox);
            this.table = table;
            button = new JButton("삭제");
            button.setOpaque(true);
            button.setBackground(Color.WHITE);
            button.setForeground(new Color(13, 39, 84));
            button.setFont(new Font("Pretendard", Font.BOLD, 14));

            button.addActionListener(e -> {
                clicked = true;
                fireEditingStopped();
            });
        }

        public Component getTableCellEditorComponent(JTable table, Object value,
                                                     boolean isSelected, int row, int column) {
            selectedRow = row;
            return button;
        }

        public Object getCellEditorValue() {
            if (clicked) {
                String routineName = (String) table.getValueAt(selectedRow, 0);
                int confirm = JOptionPane.showConfirmDialog(
                        null,
                        routineName + "을(를) 정말 삭제하시겠습니까?",
                        "삭제 확인",
                        JOptionPane.YES_NO_OPTION
                );
                if (confirm == JOptionPane.YES_OPTION) {
                    ((DefaultTableModel) table.getModel()).removeRow(selectedRow);
                    System.out.println("루틴 삭제됨: " + routineName);
                } else {
                    System.out.println("루틴 삭제 취소됨");
                }
            }
            clicked = false;
            return "삭제";
        }

        public boolean stopCellEditing() {
            clicked = false;
            return super.stopCellEditing();
        }
    }

    public static void main(String[] args) {
        new RoutineManagementPage();
    }
}
