// encoding: UTF-8
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;


import java.io.*;
import model.RoutineSelectionData;
import model.RoutineCard;
import java.util.Map;
import com.google.gson.Gson;


public class SaveRoutineUI extends JFrame {

    public SaveRoutineUI() {
        setTitle("루틴 저장");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        getContentPane().setBackground(new Color(3, 46, 104));
        setLayout(new BorderLayout());

        // === 상단 전체 패널 ===
        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(new BoxLayout(headerPanel, BoxLayout.Y_AXIS));
        headerPanel.setBackground(new Color(3, 46, 104));

        // 제목 + 버튼 패널
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(new Color(3, 46, 104));
        topPanel.setBorder(new EmptyBorder(30, 40, 10, 40));

        JLabel titleLabel = new JLabel("완성된 루틴 저장 페이지예요!");
        titleLabel.setFont(new Font("Malgun Gothic", Font.BOLD, 36));
        titleLabel.setForeground(Color.WHITE);
        topPanel.add(titleLabel, BorderLayout.WEST);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        buttonPanel.setBackground(new Color(3, 46, 104));

        JButton mypageButton = new JButton("마이페이지");
        JButton homeButton = new JButton("홈");
        mypageButton.setFont(new Font("Malgun Gothic", Font.PLAIN, 14));
        homeButton.setFont(new Font("Malgun Gothic", Font.PLAIN, 14));

        mypageButton.addActionListener(e -> {
            new MyPageUI().setVisible(true);
            dispose();
        });
        homeButton.addActionListener(e -> {
            new MainPage().setVisible(true);
            dispose();
        });

        buttonPanel.add(homeButton);
        buttonPanel.add(mypageButton);
        topPanel.add(buttonPanel, BorderLayout.EAST);

        // 설명 라벨 및 구분선
        JPanel descPanel = new JPanel();
        descPanel.setLayout(new BoxLayout(descPanel, BoxLayout.Y_AXIS));
        descPanel.setBackground(new Color(3, 46, 104));
        descPanel.setBorder(new EmptyBorder(0, 40, 20, 40));

        JLabel descLabel = new JLabel("원하는 형식에 체크 표시하고, 전송 버튼 누르면 저장된 전화번호로 해당 파일 전송해 드립니다");
        descLabel.setFont(new Font("Malgun Gothic", Font.PLAIN, 15));
        descLabel.setForeground(Color.WHITE);
        descLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JSeparator separator = new JSeparator();
        separator.setMaximumSize(new Dimension(600, 2));
        separator.setForeground(Color.LIGHT_GRAY);

        descPanel.add(descLabel);
        descPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        descPanel.add(separator);
        descPanel.add(Box.createRigidArea(new Dimension(0, 10)));

        // 상단 통합
        headerPanel.add(topPanel);
        headerPanel.add(descPanel);
        add(headerPanel, BorderLayout.NORTH);

        // === 메인 선택 박스 ===
        JPanel centerPanel = new JPanel(new GridLayout(1, 2, 60, 0));
        centerPanel.setBackground(new Color(3, 46, 104));
        centerPanel.setBorder(new EmptyBorder(10, 60, 30, 60));

        Font labelFont = new Font("Malgun Gothic", Font.BOLD, 16);
        Font textFont = new Font("Consolas", Font.PLAIN, 12);

        // JSON 패널
        JPanel jsonPanel = new JPanel();
        jsonPanel.setLayout(new BoxLayout(jsonPanel, BoxLayout.Y_AXIS));
        jsonPanel.setBackground(new Color(3, 46, 104));

        JCheckBox jsonCheck = new JCheckBox("JSON 형식으로 저장하기");
        jsonCheck.setFont(labelFont);
        jsonCheck.setForeground(Color.WHITE);
        jsonCheck.setBackground(new Color(3, 46, 104));
        jsonCheck.setSelected(true);
        jsonCheck.setAlignmentX(Component.CENTER_ALIGNMENT);

        JTextArea jsonArea = new JTextArea(
            "{\n" +
            "  \"date\": \"2025-05-19\",\n" +
            "  \"schedule\": [\n" +
            "    {\"time\": \"21:25\", \"step\": \"DINNER\", \"desc\": \"따뜻한 저녁 식사로 몸과 마음을 달래기\", \"activity\": \"버섯 전골\"},\n" +
            "    {\"time\": \"22:25\", \"step\": \"CONTENT TIME\", \"desc\": \"가볍고 편안한 콘텐츠로 휴식 시간 즐기기\", \"activity\": \"넷플릭스 <오늘도 무사히>\"},\n" +
            "    {\"time\": \"23:45\", \"step\": \"WIND DOWN\", \"desc\": \"샤워 후 스트레칭으로 하루 마무리 준비\", \"activity\": \"유튜브 <10분 전신 풀기 루틴>\"},\n" +
            "    {\"time\": \"00:25\", \"step\": \"WRAP UP\", \"desc\": \"휴식 마무리, 마음 정리 후 취침\", \"activity\": \"디카페인 차 한 잔\"}\n" +
            "  ]\n" +
            "}"
        );
        jsonArea.setFont(textFont);
        jsonArea.setForeground(Color.WHITE);
        jsonArea.setBackground(new Color(3, 46, 104));
        jsonArea.setEditable(false);
        jsonArea.setBorder(new CompoundBorder(
            BorderFactory.createLineBorder(Color.LIGHT_GRAY),
            new EmptyBorder(10, 10, 10, 10)
        ));
        jsonArea.setMaximumSize(new Dimension(380, 220));

        jsonPanel.add(jsonCheck);
        jsonPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        jsonPanel.add(jsonArea);

        // TXT 패널
        JPanel txtPanel = new JPanel();
        txtPanel.setLayout(new BoxLayout(txtPanel, BoxLayout.Y_AXIS));
        txtPanel.setBackground(new Color(3, 46, 104));

        JCheckBox txtCheck = new JCheckBox("TXT 형식으로 저장하기");
        txtCheck.setFont(labelFont);
        txtCheck.setForeground(Color.WHITE);
        txtCheck.setBackground(new Color(3, 46, 104));
        txtCheck.setAlignmentX(Component.CENTER_ALIGNMENT);

        JTextArea txtArea = new JTextArea(
            "📅 2025-05-20\n\n" +
            "21:25 | DINNER       | 따뜻한 저녁 식사로 몸과 마음을 달래기\n" +
            "                    | 버섯 전골\n\n" +
            "22:25 | CONTENT TIME | 가볍고 편안한 콘텐츠로 휴식 시간 즐기기\n" +
            "                    | 넷플릭스 <오늘도 무사히>\n\n" +
            "23:45 | WIND DOWN    | 샤워 후 스트레칭으로 하루 마무리 준비\n" +
            "                    | 유튜브 <10분 전신 풀기 루틴>\n\n" +
            "00:25 | WRAP UP      | 휴식 마무리, 마음 정리 후 취침\n" +
            "                    | 디카페인 차 한 잔"
        );
        txtArea.setFont(new Font("Malgun Gothic", Font.PLAIN, 12));
        txtArea.setForeground(Color.WHITE);
        txtArea.setBackground(new Color(3, 46, 104));
        txtArea.setEditable(false);
        txtArea.setBorder(new CompoundBorder(
            BorderFactory.createLineBorder(Color.LIGHT_GRAY),
            new EmptyBorder(10, 10, 10, 10)
        ));
        txtArea.setMaximumSize(new Dimension(380, 220));

        txtPanel.add(txtCheck);
        txtPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        txtPanel.add(txtArea);

        centerPanel.add(jsonPanel);
        centerPanel.add(txtPanel);
        add(centerPanel, BorderLayout.CENTER);

        // 하단 버튼
        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(new Color(3, 46, 104));
        JButton completeButton = new JButton("선택 완료");
        completeButton.addActionListener(e -> {
            RoutineCard selected = RoutineSelectionData.getSelectedRoutine();
            Gson gson = new Gson();

            if (jsonCheck.isSelected()) {
                try (Writer writer = new FileWriter("saved_routine.json")) {
                    gson.toJson(selected, writer);
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }

            if (txtCheck.isSelected()) {
                try (Writer writer = new FileWriter("saved_routine.txt")) {
                    writer.write("📅 저장된 루틴\n\n");
                    writer.write("• 저녁: " + selected.getDinnerDetail() + "\n");
                    writer.write("• 활동: " + selected.getActivityDetail() + "\n");
                    writer.write("• 마무리: " + selected.getClosingDetail() + "\n");
                } catch (IOException ex) {
                    ex.printStackTrace();
                }
            }

            dispose();
            new RoutineDonePage().setVisible(true);
        });
        completeButton.setFont(new Font("Malgun Gothic", Font.BOLD, 14));
        completeButton.setPreferredSize(new Dimension(120, 40));
        bottomPanel.add(completeButton);
        add(bottomPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(SaveRoutineUI::new);
    }
}
