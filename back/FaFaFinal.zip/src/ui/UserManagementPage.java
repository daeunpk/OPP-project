import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.io.FileReader;
import java.util.List;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.util.ArrayList;
import java.util.Map;

public class UserManagementPage extends JFrame {

    public UserManagementPage() {
        setTitle("유저 관리");
        setSize(1280, 800);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(new Color(13, 39, 84));

        JPanel topBar = new JPanel(null);
        topBar.setBounds(0, 0, 1280, 80);
        topBar.setBackground(new Color(13, 39, 84));
        add(topBar);

        JButton backButton = new JButton("이전");
        backButton.setFont(new Font("SansSerif", Font.BOLD, 18));
        backButton.setBounds(20, 20, 50, 40);
        topBar.add(backButton);
        backButton.addActionListener(e -> {
            new AdminDashboardPage().setVisible(true);
            dispose();
        });

        JLabel titleLabel = new JLabel("유저 관리", SwingConstants.CENTER);
        titleLabel.setFont(new Font("맑은 고딕", Font.BOLD, 28));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBounds(0, 20, 1280, 40);
        topBar.add(titleLabel);

        JLabel dateLabel = new JLabel("2025년 5월 19일", SwingConstants.RIGHT);
        dateLabel.setForeground(Color.WHITE);
        dateLabel.setFont(new Font("맑은 고딕", Font.PLAIN, 16));
        dateLabel.setBounds(1000, 20, 200, 40);
        topBar.add(dateLabel);

        JButton saveButton = new JButton("저장");
        saveButton.setBounds(1200, 20, 30, 30);
        topBar.add(saveButton);

        JButton homeButton = new JButton("홈");
        homeButton.setBounds(1240, 20, 30, 30);
        topBar.add(homeButton);
        homeButton.addActionListener(e -> {
            new MainPage().setVisible(true);
            dispose();
        });

        String[] columns = {"이름", "사번", "전화 번호", "최근 접속일", "관리"};
        Object[][] data = loadUserData("storage/users.json");

        DefaultTableModel model = new DefaultTableModel(data, columns) {
            public boolean isCellEditable(int row, int column) {
                return column == 4;
            }
        };

        JTable table = new JTable(model);
        table.setRowHeight(40);
        table.setFont(new Font("맑은 고딕", Font.PLAIN, 16));
        table.setForeground(Color.WHITE);
        table.setBackground(new Color(13, 39, 84));
        table.setGridColor(Color.WHITE);
        table.setShowHorizontalLines(true);
        table.setShowVerticalLines(false);

        table.getColumnModel().getColumn(0).setPreferredWidth(150);
        table.getColumnModel().getColumn(1).setPreferredWidth(150);
        table.getColumnModel().getColumn(2).setPreferredWidth(250);
        table.getColumnModel().getColumn(3).setPreferredWidth(150);
        table.getColumnModel().getColumn(4).setPreferredWidth(100);

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        for (int i = 0; i < table.getColumnCount(); i++) {
            if (!table.getColumnName(i).equals("관리")) {
                table.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
            }
        }

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("맑은 고딕", Font.BOLD, 16));
        header.setBackground(new Color(13, 39, 84));
        header.setForeground(Color.WHITE);

        table.getColumn("관리").setCellRenderer(new ButtonRenderer());
        table.getColumn("관리").setCellEditor(new ButtonEditor(new JCheckBox(), table));

        JScrollPane scrollPane = new JScrollPane(table);
        int tableHeight = table.getRowHeight() * table.getRowCount() + header.getPreferredSize().height;
        scrollPane.setBounds(100, 120, 1080, tableHeight - 700);
        add(scrollPane);

        setVisible(true);
    }

    private Object[][] loadUserData(String filePath) {
        List<Map<String, String>> userList = new ArrayList<>();
        try {
            Gson gson = new Gson();
            FileReader reader = new FileReader(filePath);
            java.lang.reflect.Type type = new TypeToken<List<Map<String, String>>>() {}.getType();
            userList = gson.fromJson(reader, type);
            reader.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        Object[][] data = new Object[userList.size()][5];
        for (int i = 0; i < userList.size(); i++) {
            Map<String, String> user = userList.get(i);
            data[i][0] = user.get("name");
            data[i][1] = user.get("emID");
            data[i][2] = user.get("phone");
            data[i][3] = "25/05/19";
            data[i][4] = "탈퇴";
        }
        return data;
    }

    class ButtonRenderer extends JButton implements javax.swing.table.TableCellRenderer {
        public ButtonRenderer() {
            setOpaque(true);
            setText("탈퇴");
            setBackground(Color.WHITE);
            setForeground(new Color(13, 39, 84));
            setFont(new Font("맑은 고딕", Font.BOLD, 14));
        }

        public Component getTableCellRendererComponent(JTable table, Object value,
                                                       boolean isSelected, boolean hasFocus, int row, int column) {
            return this;
        }
    }

    class ButtonEditor extends DefaultCellEditor {
        private JButton button;
        private boolean clicked;
        private int selectedRow;
        private JTable table;

        public ButtonEditor(JCheckBox checkBox, JTable table) {
            super(checkBox);
            this.table = table;
            button = new JButton("탈퇴");
            button.setOpaque(true);
            button.setBackground(Color.WHITE);
            button.setForeground(new Color(13, 39, 84));
            button.setFont(new Font("맑은 고딕", Font.BOLD, 14));

            button.addActionListener(e -> {
                clicked = true;
                fireEditingStopped();
            });
        }

        public Component getTableCellEditorComponent(JTable table, Object value,
                                                     boolean isSelected, int row, int column) {
            selectedRow = row;
            return button;
        }

        public Object getCellEditorValue() {
            if (clicked) {
                String name = (String) table.getValueAt(selectedRow, 0);
                int confirm = JOptionPane.showConfirmDialog(
                        null,
                        name + "님을 정말 탈퇴시키겠습니까?",
                        "확인",
                        JOptionPane.YES_NO_OPTION
                );
                if (confirm == JOptionPane.YES_OPTION) {
                    ((DefaultTableModel) table.getModel()).removeRow(selectedRow);
                    System.out.println("탈퇴 처리됨: " + name);
                } else {
                    System.out.println("탈퇴 취소됨");
                }
            }
            clicked = false;
            return "탈퇴";
        }

        public boolean stopCellEditing() {
            clicked = false;
            return super.stopCellEditing();
        }
    }

    public static void main(String[] args) {
        new UserManagementPage();
    }
}
