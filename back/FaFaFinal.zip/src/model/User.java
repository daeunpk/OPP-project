package model;

public class User {
    private String name;
    private String age;
    private String address;
    private String email;
    private String emID;

    public User(String name, String age, String address, String email, String emID) {
        this.name = name;
        this.age = age;
        this.address = address;
        this.email = email;
        this.emID = emID;
    }

    // Getter만 생성 (Gson은 기본 생성자 없이도 가능)
    public String getName() { return name; }
    public String getAge() { return age; }
    public String getAddress() { return address; }
    public String getEmail() { return email; }
    public String getEmID() { return emID; }
}
