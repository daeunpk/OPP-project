
package model;

import java.util.HashMap;
import java.util.Map;
import model.RoutineCard;

public class RoutineSelectionData {
    private static RoutineCard selectedRoutine;
    private static Map<String, String> selectedDetails = new HashMap<>();

    public static void setSelectedRoutine(RoutineCard routine) {
        selectedRoutine = routine;
    }

    public static RoutineCard getSelectedRoutine() {
        return selectedRoutine;
    }

    public static void setDetail(String category, String detail) {
        selectedDetails.put(category, detail);
    }

    public static Map<String, String> getSelectedDetails() {
        return selectedDetails;
    }

    public static void clear() {
        selectedRoutine = null;
        selectedDetails.clear();
    }
}
