import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.Enumeration;
import model.*;
import service.*;
import java.time.LocalTime;
import java.util.List;



public class RoutineRecommendationUI extends JFrame {

    private UserStatus userStatus;
    private LocalTime endTime;
    private List<RoutineCard> routines;


    public RoutineRecommendationUI(UserStatus userStatus, LocalTime endTime) {
        this.userStatus = userStatus;
        this.endTime = endTime;

        setTitle("GOODBYE-OFFICE");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);

        setSize(900, 700);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBackground(new Color(250, 240, 230));
        mainPanel.setBorder(new EmptyBorder(20, 40, 20, 40));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(10, 0, 10, 0);

        Font smallFont = new Font("Malgun Gothic", Font.PLAIN, 11);
        Font subFont = new Font("Malgun Gothic", Font.BOLD, 12);
        Font buttonFont = new Font("Malgun Gothic", Font.PLAIN, 13);
        Font basicFont = new Font("Malgun Gothic", Font.BOLD, 15);
        Font labelFont = new Font("Malgun Gothic", Font.BOLD, 18);
        Font titleFont = new Font("Malgun Gothic", Font.BOLD, 22);

        // 상단 버튼
        JPanel topButtonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        topButtonPanel.setBackground(mainPanel.getBackground());
        topButtonPanel.setPreferredSize(new Dimension(350, 40));

        JButton refreshButton = new JButton("다시 추천");
        JButton mypageButton = new JButton("마이페이지");
		mypageButton.addActionListener(e -> {
            new MyPageUI().setVisible(true); // 첫 화면 클래스 이름이 StartPage일 경우 수정
            dispose(); // 현재 창 닫기
        });
        JButton homeButton = new JButton("홈");
        homeButton.addActionListener(e -> {
            new MainPage().setVisible(true);  // 예시: 첫 페이지
            dispose();
        });
        refreshButton.setFont(buttonFont);
        mypageButton.setFont(buttonFont);
        homeButton.setFont(buttonFont);
        topButtonPanel.add(refreshButton);
        topButtonPanel.add(mypageButton);
        topButtonPanel.add(homeButton);

        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.NORTHEAST;
        gbc.fill = GridBagConstraints.NONE;
        mainPanel.add(topButtonPanel, gbc);

        // 타이틀
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        JLabel titleLabel = new JLabel("당신에게 추천된 루틴입니다!");
        titleLabel.setFont(titleFont);
        titleLabel.setForeground(new Color(0x4E4E4E));
        titleLabel.setHorizontalAlignment(JLabel.LEFT);
        mainPanel.add(titleLabel, gbc);

        // 서브 타이틀
        gbc.gridy++;
        JLabel subtitleLabel = new JLabel("기분 상태: 활기참 / 예상 퇴근: 20:45");
        subtitleLabel.setFont(subFont);
        subtitleLabel.setForeground(new Color(0x8B2C46));
        subtitleLabel.setHorizontalAlignment(JLabel.RIGHT);
        mainPanel.add(subtitleLabel, gbc);

        // 구분선
        gbc.gridy++;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.weightx = 1;
        gbc.weighty = 0;

        JPanel linePanel = new JPanel();
        linePanel.setBackground(new Color(0x4E4E4E));
        linePanel.setPreferredSize(new Dimension(600, 2));
        mainPanel.add(linePanel, gbc);
        gbc.gridwidth = 1;

        // 루틴 카드
        gbc.gridy++;
        gbc.fill = GridBagConstraints.BOTH;
        gbc.weightx = 1;
        gbc.weighty = 1;

        JPanel routinePanel = new JPanel(new GridLayout(1, 3, 10, 0));
        routinePanel.setBackground(mainPanel.getBackground());
        ButtonGroup routineGroup = new ButtonGroup();

        RoutineRecommender recommender = new RoutineRecommender();
        List<RoutineCard> result = recommender.recommend(userStatus);
        this.routines = result;
        System.out.println("추천 결과 수: " + result.size());

        for (int i = 0; i < result.size(); i++) {
            RoutineCard card = routines.get(i);
            JPanel singleRoutine = createRoutinePanel("루틴 " + (i + 1), card, labelFont, basicFont, smallFont, routineGroup);
            routinePanel.add(singleRoutine);
        }


//        for (int i = 1; i <= 3; i++) {
//            JPanel singleRoutine = createRoutinePanel("루틴 " + i, labelFont, basicFont, smallFont, routineGroup);
//            routinePanel.add(singleRoutine);
//        }

        mainPanel.add(routinePanel, gbc);

        // 여백
        gbc.gridy++;
        gbc.weighty = 1;
        gbc.fill = GridBagConstraints.VERTICAL;
        mainPanel.add(Box.createVerticalGlue(), gbc);

        // 제출 버튼
        gbc.gridy++;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.SOUTHEAST;
        gbc.fill = GridBagConstraints.NONE;

        JButton submitButton = new JButton("선택 완료");
        submitButton.setFont(buttonFont);

        // ✅ 상세 루틴 화면으로 이동
        submitButton.addActionListener(e -> {
            Enumeration<AbstractButton> buttons = routineGroup.getElements();
            boolean selected = false;

            while (buttons.hasMoreElements()) {
                AbstractButton btn = buttons.nextElement();
                if (btn.isSelected()) {
                    selected = true;
                    break;
                }
            }

            if (selected) {
                new DetailedRoutineUI().setVisible(true);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "루틴을 선택해주세요.");
            }
        });

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        buttonPanel.setBackground(mainPanel.getBackground());
        buttonPanel.setPreferredSize(new Dimension(350, 40));
        buttonPanel.add(submitButton);
        mainPanel.add(buttonPanel, gbc);

        add(mainPanel);
        setVisible(true);
    }

    private JPanel createRoutinePanel(String title, RoutineCard card, Font labelFont, Font basicFont, Font smallFont, ButtonGroup group) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(new Color(250, 240, 230));
        panel.setBorder(new EmptyBorder(10, 10, 10, 10));

        JRadioButton radioButton = new JRadioButton();
        radioButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        radioButton.setBackground(panel.getBackground());
        group.add(radioButton);
        panel.add(radioButton);

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(labelFont);
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(titleLabel);

        JLabel subtitle = new JLabel("각 루틴에는 예상되는 활동들이 있어요");
        subtitle.setFont(smallFont);
        subtitle.setForeground(new Color(0x8B2C46));
        subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);
        panel.add(subtitle);

        panel.add(Box.createVerticalStrut(8));
        panel.add(makeSeparator());
        panel.add(Box.createVerticalStrut(8));
        panel.add(makeTimeBlock("21:25", "저녁식사", "가벼운 식사나 야식 추천", basicFont, smallFont));
        panel.add(Box.createVerticalStrut(8));
        panel.add(makeSeparator());
        panel.add(Box.createVerticalStrut(8));
        panel.add(makeTimeBlock("22:25", "콘텐츠 타임", "영상, 독서 등 나만의 콘텐츠 타임", basicFont, smallFont));
        panel.add(Box.createVerticalStrut(8));
        panel.add(makeSeparator());
        panel.add(Box.createVerticalStrut(8));
        panel.add(makeTimeBlock("23:45", "마무리 루틴", "명상, 스트레칭 등 이완 활동", basicFont, smallFont));
        panel.add(Box.createVerticalStrut(8));
        panel.add(makeSeparator());
        panel.add(Box.createVerticalStrut(8));
        panel.add(makeTimeBlock("00:30", "잠들기 전", "스마트폰 정리 및 침대에 눕기", basicFont, smallFont));

        return panel;
    }

    private JPanel makeTimeBlock(String time, String category, String desc, Font catFont, Font descFont) {
        JPanel block = new JPanel(new BorderLayout());
        block.setBackground(new Color(250, 240, 230));
        block.setBorder(new EmptyBorder(5, 10, 5, 10));

        JLabel timeLabel = new JLabel(time);
        timeLabel.setFont(catFont);
        timeLabel.setPreferredSize(new Dimension(60, 30));
        block.add(timeLabel, BorderLayout.WEST);

        JPanel rightPanel = new JPanel();
        rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS));
        rightPanel.setBackground(block.getBackground());

        JLabel catLabel = new JLabel(category);
        catLabel.setFont(catFont);
        catLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel descLabel = new JLabel("<html><div style='width:130px; word-break:normal;'>" + desc + "</div></html>");
        descLabel.setFont(descFont);
        descLabel.setForeground(Color.DARK_GRAY);
        descLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        rightPanel.add(catLabel);
        rightPanel.add(Box.createVerticalStrut(5));
        rightPanel.add(descLabel);

        block.add(rightPanel, BorderLayout.CENTER);
        return block;
    }

    private JSeparator makeSeparator() {
        JSeparator separator = new JSeparator(SwingConstants.HORIZONTAL);
        separator.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        separator.setForeground(Color.GRAY);
        return separator;
    }


//    public static void main(String[] args) {
//        SwingUtilities.invokeLater(RoutineRecommendationUI::new);
//    }
}
