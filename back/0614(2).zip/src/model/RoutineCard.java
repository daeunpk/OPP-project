package model;

public class RoutineCard {
    private String dinnerCategory;
    private String dinner;
    private String activityCategory;
    private String activity;
    private String closingCategory;
    private String closing;

    public RoutineCard(String dinnerCategory, String dinner, String activityCategory, String activity, String closingCategory, String closing) {
        this.dinnerCategory = dinnerCategory;
        this.dinner = dinner;
        this.activityCategory = activityCategory;
        this.activity = activity;
        this.closingCategory = closingCategory;
        this.closing = closing;
    }

    public String getDinnerCategory() { return dinnerCategory; }
    public String getDinner() { return dinner; }
    public String getActivityCategory() { return activityCategory; }
    public String getActivity() { return activity; }
    public String getClosingCategory() { return closingCategory; }
    public String getClosing() { return closing; }

    @Override
    public String toString() {
        return "[저녁] " + dinnerCategory + ": " + dinner +
                "\n[활동] " + activityCategory + ": " + activity +
                "\n[마무리] " + closingCategory + ": " + closing;
    }
}



//package model;
//
//public class RoutineCard {
//    private String dinner;
//    private String activity1;
//    private String activity2;
//    private String closing;
//
//    public RoutineCard(String dinner, String activity1, String activity2, String closing) {
//        this.dinner = dinner;
//        this.activity1 = activity1;
//        this.activity2 = activity2;
//        this.closing = closing;
//    }
//
//    public String getDinner() { return dinner; }
//    public String getActivity1() { return activity1; }
//    public String getActivity2() { return activity2; }
//    public String getClosing() { return closing; }
//}
