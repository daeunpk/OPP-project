package service;

import com.google.gson.*;
import model.RoutineCard;
import model.UserStatus;

import java.io.FileReader;
import java.time.LocalTime;
import java.util.*;

public class RoutineRecommender {

    private static final String JSON_PATH = "C:/Users/dldna/OneDrive/바탕 화면/0614(2)/src/storage/routines.json";


    public List<RoutineCard> recommend(UserStatus userStatus) {
        System.out.println("📅 UserStatus: " + userStatus);
        LocalTime endTime = LocalTime.parse(userStatus.getEndTime());
        System.out.println("⏰ endTime: " + endTime);

        List<String> userTags = buildTags(userStatus, endTime);
        List<RoutineCard> result = new ArrayList<>();

        try {
            JsonArray rootArray = JsonParser.parseReader(new FileReader(JSON_PATH)).getAsJsonArray();

            for (JsonElement element : rootArray) {
                JsonObject routineGroup = element.getAsJsonObject();
                JsonArray tagArray = routineGroup.getAsJsonArray("tags");

                boolean allMatch = true;
                for (JsonElement tagElem : tagArray) {
                    if (!userTags.contains(tagElem.getAsString())) {
                        allMatch = false;
                        break;
                    }
                }

                if (allMatch) {
                    JsonArray routines = routineGroup.getAsJsonArray("routines");

                    for (JsonElement routineElem : routines) {
                        JsonObject routineObj = routineElem.getAsJsonObject();

                        JsonObject dinnerObj = routineObj.getAsJsonObject("dinner");
                        String dinnerCategory = dinnerObj.get("category").getAsString();
                        JsonArray dinnerOptions = dinnerObj.getAsJsonArray("options");

                        JsonObject activityObj = routineObj.getAsJsonObject("activity");
                        String activityCategory = activityObj.get("category").getAsString();
                        JsonArray activityOptions = activityObj.getAsJsonArray("options");

                        JsonObject closingObj = routineObj.getAsJsonObject("closing");
                        String closingCategory = closingObj.get("category").getAsString();
                        JsonArray closingOptions = closingObj.getAsJsonArray("options");

                        String dinner = dinnerOptions.get(new Random().nextInt(dinnerOptions.size())).getAsString();
                        String activity = activityOptions.get(new Random().nextInt(activityOptions.size())).getAsString();
                        String closing = closingOptions.get(new Random().nextInt(closingOptions.size())).getAsString();

                        RoutineCard card = new RoutineCard(
                                dinnerCategory, dinner,
                                activityCategory, activity,
                                closingCategory, closing
                        );
                        result.add(card);
                    }
                    break; // 태그 일치하는 그룹 1개만 사용
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return result;
    }

    private List<String> buildTags(UserStatus userStatus, LocalTime endTime) {
        List<String> tags = new ArrayList<>();

        // 감정
        String mood = userStatus.getMood();
        if (mood.contains("좋")) tags.add("기분 좋음");
        else if (mood.contains("나쁨")) tags.add("기분 나쁨");
        else tags.add("기분 보통");

        // 활력
        int energy = userStatus.getEnergy();
        if (energy >= 4) tags.add("활력 높음");
        else if (energy >= 2) tags.add("활력 보통");
        else tags.add("활력 낮음");

        // 동행
        tags.add(userStatus.getCompanion()); // "혼자" or "사람 만남"

        // 시간 여유
        if (endTime.isBefore(LocalTime.of(18, 30))) tags.add("시간 많음");
        else tags.add("시간 적음");

        System.out.println("🎯 userTags = " + tags);
        return tags;
    }

    private static String pickFromCategory(JsonArray array, List<String> userTags) {
        List<String> candidates = new ArrayList<>();
        for (JsonElement e : array) {
            JsonObject obj = e.getAsJsonObject();
            JsonArray tagArray = obj.getAsJsonArray("tags");
            if (matchesTags(tagArray, userTags)) {
                JsonArray examples = obj.getAsJsonArray("examples");
                for (JsonElement ex : examples) {
                    candidates.add(ex.getAsString());
                }
            }
        }
        if (candidates.isEmpty()) {
            System.out.println("❌ 조건에 맞는 루틴 없음. userTags = " + userTags);
            return "기본 루틴";
        }
        return candidates.get(new Random().nextInt(candidates.size()));
    }

    private static List<String> pickMultipleFromCategory(JsonArray array, List<String> userTags, int count) {
        Set<String> result = new HashSet<>();
        for (JsonElement e : array) {
            JsonObject obj = e.getAsJsonObject();
            JsonArray tagArray = obj.getAsJsonArray("tags");
            if (matchesTags(tagArray, userTags)) {
                JsonArray examples = obj.getAsJsonArray("examples");
                for (JsonElement ex : examples) {
                    result.add(ex.getAsString());
                }
            }
        }
        List<String> shuffled = new ArrayList<>(result);
        Collections.shuffle(shuffled);
        while (shuffled.size() < count) shuffled.add("기본 활동");
        return shuffled.subList(0, count);
    }

    private static boolean matchesTags(JsonArray candidateTags, List<String> userTags) {
        for (JsonElement tag : candidateTags) {
            if (userTags.contains(tag.getAsString())) return true;
        }
        return false;
    }
}
