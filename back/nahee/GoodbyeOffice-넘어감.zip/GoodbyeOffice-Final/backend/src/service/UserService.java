package service;

import dto.UserLoginRequest;
import dto.UserSignUpRequest;

import java.util.ArrayList;
import java.util.List;

public class UserService {
    // ✅ 사용자 정보 저장용 리스트 (이름 + 사번 쌍)
    private static List<UserRecord> userStore = new ArrayList<>();

    // ✅ 내부 클래스로 이름 + 사번 저장
    private static class UserRecord {
        String name;
        String password;

        UserRecord(String name, String password) {
            this.name = name;
            this.password = password;
        }
    }

    public static boolean signUp(UserSignUpRequest req) {
        // 이름과 사번이 모두 같은 사용자 존재 여부 확인
        for (UserRecord user : userStore) {
            if (user.name.equals(req.getName()) && user.password.equals(req.getPassword())) {
                return false;
            }
        }
        userStore.add(new UserRecord(req.getName(), req.getPassword()));
        return true;
    }

    public static boolean login(UserLoginRequest req) {
        for (UserRecord user : userStore) {
            if (user.name.equals(req.getName()) && user.password.equals(req.getPassword())) {
                return true;
            }
        }
        return false;
    }
}
