package model;

import java.util.List;

public class Routine {
    private String name;
    private List<String> steps;

    // ✅ 이 생성자를 추가하면 에러 해결됩니다
    public Routine(String name, List<String> steps) {
        this.name = name;
        this.steps = steps;
    }

    public Routine() {
        // 기본 생성자도 유지 가능
    }

    // Getter/Setter 필요 시 추가
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public List<String> getSteps() { return steps; }
    public void setSteps(List<String> steps) { this.steps = steps; }
}