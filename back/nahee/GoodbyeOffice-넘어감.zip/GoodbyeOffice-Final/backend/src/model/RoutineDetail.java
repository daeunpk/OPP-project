package model;

import java.util.List;

public class RoutineDetail {
    public String routineName;
    public List<String> selectedDetails;
}