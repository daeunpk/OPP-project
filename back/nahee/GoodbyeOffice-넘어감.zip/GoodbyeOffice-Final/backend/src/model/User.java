package model;

public class User {
    private String name;
    private String role;

    // ✅ 문제 해결용 생성자 추가
    public User(String name, String role) {
        this.name = name;
        this.role = role;
    }

    // 기본 생성자도 남겨둘 수 있습니다 (필요 시)
    public User() {
    }

    // getter/setter 생략 가능
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }
}