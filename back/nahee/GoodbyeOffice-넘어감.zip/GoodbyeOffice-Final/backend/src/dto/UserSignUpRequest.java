package dto;

public class UserSignUpRequest {
    private String name;
    private String password;

    public String getName() { return name; }
    public String getPassword() { return password; }
}