package controller;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import dto.UserLoginRequest;
import dto.UserSignUpRequest;
import service.UserService;
import com.google.gson.Gson;

import java.io.IOException;
import java.io.OutputStream;

public class UserController implements HttpHandler {

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        String path = exchange.getRequestURI().getPath();
        String method = exchange.getRequestMethod();

        if (path.endsWith("/signup") && method.equalsIgnoreCase("POST")) {
            handleSignUp(exchange);
        } else if (path.endsWith("/login") && method.equalsIgnoreCase("POST")) {
            handleLogin(exchange);
        } else {
            exchange.sendResponseHeaders(404, -1);
        }
    }

    private void handleSignUp(HttpExchange exchange) throws IOException {
        String body = new String(exchange.getRequestBody().readAllBytes());
        UserSignUpRequest request = new Gson().fromJson(body, UserSignUpRequest.class);

        boolean success = UserService.signUp(request);
        String response = success ? "가입 성공" : "이미 존재하는 사용자";

        exchange.sendResponseHeaders(200, response.getBytes().length);
        OutputStream os = exchange.getResponseBody();
        os.write(response.getBytes());
        os.close();
    }

    private void handleLogin(HttpExchange exchange) throws IOException {
        String body = new String(exchange.getRequestBody().readAllBytes());
        UserLoginRequest request = new Gson().fromJson(body, UserLoginRequest.class);

        boolean authenticated = UserService.login(request);
        String response = authenticated ? "로그인 성공" : "로그인 실패";

        exchange.sendResponseHeaders(200, response.getBytes().length);
        OutputStream os = exchange.getResponseBody();
        os.write(response.getBytes());
        os.close();
    }
}