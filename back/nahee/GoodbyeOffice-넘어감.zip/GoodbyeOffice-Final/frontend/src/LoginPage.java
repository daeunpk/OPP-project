// 로그인 성공 시 UserStatusUI로 이동하는 흐름 구현 예시 + 사용자 상태 전달 + 사용자 상태 서버 전송 후 루틴 분기

import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

public class LoginPage extends JFrame {
    public LoginPage() {
        setTitle("로그인");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(13, 39, 84));
        setLayout(null);

        int fieldWidth = 250;
        int fieldHeight = 30;
        int labelWidth = 80;
        int startX = 500;
        int startY = 200;
        int gap = 50;

        JLabel title = new JLabel("로그인");
        title.setFont(new Font("맑은 고딕", Font.BOLD, 30));
        title.setForeground(Color.WHITE);
        title.setBounds(startX, 60, 300, 50);
        add(title);

        JLabel nameLabel = new JLabel("이름:");
        nameLabel.setForeground(Color.WHITE);
        nameLabel.setBounds(startX, startY, labelWidth, fieldHeight);
        add(nameLabel);

        JTextField nameField = new JTextField();
        nameField.setBounds(startX + labelWidth + 10, startY, fieldWidth, fieldHeight);
        add(nameField);

        JLabel idLabel = new JLabel("사번:");
        idLabel.setForeground(Color.WHITE);
        idLabel.setBounds(startX, startY + gap, labelWidth, fieldHeight);
        add(idLabel);

        JTextField idField = new JTextField();
        idField.setBounds(startX + labelWidth + 10, startY + gap, fieldWidth, fieldHeight);
        add(idField);

        JButton loginBtn = new JButton("로그인");
        loginBtn.setBounds(startX, startY + gap * 2, fieldWidth + labelWidth + 10, 40);
        loginBtn.setBackground(Color.WHITE);
        loginBtn.setForeground(new Color(13, 39, 84));
        loginBtn.setFont(new Font("맑은 고딕", Font.BOLD, 16));
        add(loginBtn);

        JButton signUpBtn = new JButton("회원가입");
        signUpBtn.setBounds(startX, startY + gap * 2 + 60, fieldWidth + labelWidth + 10, 40);
        signUpBtn.setBackground(Color.LIGHT_GRAY);
        signUpBtn.setFont(new Font("맑은 고딕", Font.PLAIN, 14));
        add(signUpBtn);

        loginBtn.addActionListener(e -> {
            String name = nameField.getText();
            String id = idField.getText();
            String json = String.format("{\"name\":\"%s\", \"password\":\"%s\"}", name, id);
            String result = sendPost("http://localhost:8080/users/login", json);

            if (result.contains("성공")) {
                UserSession.getInstance().login(name, id); // 로그인 정보 저장
                new UserStatusUI().setVisible(true);
                dispose();
            } else {
                JOptionPane.showMessageDialog(this, "로그인 실패: " + result);
            }
        });

        signUpBtn.addActionListener(e -> {
            new SignUpPage().setVisible(true);
            dispose();
        });

        setVisible(true);
    }

    public static String sendPost(String urlString, String jsonInput) {
        try {
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);

            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = jsonInput.getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
            StringBuilder response = new StringBuilder();
            String responseLine;

            while ((responseLine = br.readLine()) != null) {
                response.append(responseLine.trim());
            }

            return response.toString();
        } catch (IOException e) {
            return "서버 오류: " + e.getMessage();
        }
    }
}

// 사용자 세션 저장 클래스
class UserSession {
    private static UserSession instance;
    private String name;
    private String id;

    private UserSession() {}

    public static UserSession getInstance() {
        if (instance == null) instance = new UserSession();
        return instance;
    }

    public void login(String name, String id) {
        this.name = name;
        this.id = id;
    }

    public String getName() { return name; }
    public String getId() { return id; }
}
