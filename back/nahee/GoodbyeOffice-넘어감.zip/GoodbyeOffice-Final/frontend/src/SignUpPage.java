import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

public class SignUpPage extends JFrame {
    public SignUpPage() {
        setTitle("회원가입");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(13, 39, 84));
        setLayout(null);

        int fieldWidth = 250;
        int fieldHeight = 30;
        int labelWidth = 80;
        int startX = 500;
        int startY = 150;
        int gap = 50;

        JLabel title = new JLabel("회원가입");
        title.setFont(new Font("맑은 고딕", Font.BOLD, 30));
        title.setForeground(Color.WHITE);
        title.setBounds(startX, 60, 300, 50);
        add(title);

        String[] labels = {"이름", "나이", "주소", "이메일", "사번"};
        JTextField[] fields = new JTextField[labels.length];

        for (int i = 0; i < labels.length; i++) {
            JLabel label = new JLabel(labels[i] + ":");
            label.setForeground(Color.WHITE);
            label.setBounds(startX, startY + i * gap, labelWidth, fieldHeight);
            add(label);

            JTextField textField = new JTextField();
            textField.setBounds(startX + labelWidth + 10, startY + i * gap, fieldWidth, fieldHeight);
            add(textField);
            fields[i] = textField;
        }

        JButton completeBtn = new JButton("가입 완료");
        completeBtn.setBounds(startX, startY + labels.length * gap + 20, fieldWidth + labelWidth + 10, 40);
        completeBtn.setBackground(Color.WHITE);
        completeBtn.setForeground(new Color(13, 39, 84));
        completeBtn.setFont(new Font("맑은 고딕", Font.BOLD, 16));
        add(completeBtn);

        completeBtn.addActionListener(e -> {
            String name = fields[0].getText();
            String id = fields[4].getText();
            String json = String.format("{\"name\":\"%s\", \"password\":\"%s\"}", name, id);
            String result = sendPost("http://localhost:8080/users/signup", json);
            JOptionPane.showMessageDialog(this, result);
            if (result.contains("성공") || result.contains("완료") || result.contains("가입")) {
                new LoginPage().setVisible(true);
                dispose();
            }
        });

        setVisible(true);
    }

    public static String sendPost(String urlString, String jsonInput) {
        try {
            URL url = new URL(urlString);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);

            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = jsonInput.getBytes("utf-8");
                os.write(input, 0, input.length);
            }

            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "utf-8"));
            StringBuilder response = new StringBuilder();
            String responseLine;

            while ((responseLine = br.readLine()) != null) {
                response.append(responseLine.trim());
            }

            return response.toString();
        } catch (IOException e) {
            return "서버 오류: " + e.getMessage();
        }
    }
}
