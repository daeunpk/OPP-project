package model;

public class User {
    private String name;
    private String employeeId;
    private String phoneNumber;
    private String email;

    public User(String name, String employeeId, String phoneNumber, String email) {
        this.name = name;
        this.employeeId = employeeId;
        this.phoneNumber = phoneNumber;
        this.email = email;
    }

    public String getName() {
        return name;
    }

    public String getEmployeeId() {
        return employeeId;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public String getEmail() {
        return email;
    }
}
