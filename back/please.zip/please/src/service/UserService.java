package service;

import model.User;
import java.util.*;
import java.io.*;
import com.google.gson.reflect.TypeToken;
import com.google.gson.Gson;

public class UserService {
    private static final String FILE_PATH = "storage/users.json";
    private Map<String, User> users;
    private Gson gson = new Gson();

    public UserService() {
        loadUsers();
    }

    private void loadUsers() {
        try {
            File file = new File(FILE_PATH);
            if (!file.exists()) {
                users = new HashMap<>();
                saveUsers(); // 새 파일 생성
                return;
            }

            BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH));
            users = gson.fromJson(reader, new TypeToken<Map<String, User>>() {}.getType());
            if (users == null) users = new HashMap<>();
            reader.close();
        } catch (Exception e) {
            users = new HashMap<>();
            e.printStackTrace();
        }
    }

    private void saveUsers() {
        try {
            File dir = new File("storage");
            if (!dir.exists()) dir.mkdirs();

            FileWriter writer = new FileWriter(FILE_PATH);
            gson.toJson(users, writer);
            writer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean register(User user) {
        if (users.containsKey(user.getEmployeeId())) return false;
        users.put(user.getEmployeeId(), user);
        saveUsers();
        return true;
    }

    public User login(String employeeId) {
        return users.get(employeeId); // 존재하면 User 반환, 없으면 null
    }
}
