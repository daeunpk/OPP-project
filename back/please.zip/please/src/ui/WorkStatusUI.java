package ui;

// encoding: UTF-8
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.util.Hashtable;
import ui.MainPage;

public class WorkStatusUI extends JFrame {
    public WorkStatusUI() {
        setTitle("GOODBYE-OFFICE");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setLocationRelativeTo(null); // 화면 중앙에 배치

        // 메인 패널 생성
        JPanel mainPanel = new JPanel(new GridBagLayout());
        mainPanel.setBackground(new Color(250, 240, 230));
        mainPanel.setBorder(new EmptyBorder(20, 40, 20, 40));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = new Insets(10, 0, 10, 0);

        // 폰트 설정
        Font buttonFont = new Font("Malgun Gothic", Font.PLAIN, 13);
        Font labelFont = new Font("Malgun Gothic", Font.PLAIN, 16);
        Font titleFont = new Font("Malgun Gothic", Font.BOLD, 22);

        // 상단 설정 / 홈 버튼
        JPanel topButtonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        topButtonPanel.setBackground(mainPanel.getBackground());
        JButton mypageButton = new JButton("마이페이지");
        JButton homeButton = new JButton("홈");
        mypageButton.setFont(buttonFont);
        homeButton.setFont(buttonFont);
        topButtonPanel.add(mypageButton);
        topButtonPanel.add(homeButton);
        mypageButton.addActionListener(e -> {
            new MyPageUI().setVisible(true); // 첫 화면 클래스 이름이 StartPage일 경우 수정
            dispose(); // 현재 창 닫기
        });
        homeButton.addActionListener(e -> {
            new MainPage().setVisible(true); // 첫 화면 클래스 이름이 StartPage일 경우 수정
            dispose(); // 현재 창 닫기
        });

        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.anchor = GridBagConstraints.NORTHEAST;
        gbc.fill = GridBagConstraints.NONE;
        mainPanel.add(topButtonPanel, gbc);

        // 0. 제목
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        JLabel titleLabel = new JLabel("오늘 업무는 몇 시에 끝날까요?");
        titleLabel.setFont(titleFont);
        titleLabel.setForeground(new Color(0x4E4E4E));
        titleLabel.setHorizontalAlignment(JLabel.LEFT);
        mainPanel.add(titleLabel, gbc);

        // 구분선
        gbc.gridy++;
        JPanel linePanel = new JPanel();
        linePanel.setBackground(new Color(0x4E4E4E));
        linePanel.setPreferredSize(new Dimension(600, 2));
        mainPanel.add(linePanel, gbc);
        gbc.gridwidth = 1;

        // 1. 남은 업무 개수
        gbc.gridy++;
        gbc.anchor = GridBagConstraints.WEST;
        JLabel taskLabel = new JLabel("남은 업무는 몇 개인가요?");
        taskLabel.setFont(labelFont);
        mainPanel.add(taskLabel, gbc);

        gbc.gridy++;
        JPanel taskPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        taskPanel.setBackground(mainPanel.getBackground());
        JTextField taskField = new JTextField();
        taskField.setPreferredSize(new Dimension(150, 30));
        taskField.setHorizontalAlignment(JTextField.CENTER);
        JLabel unitLabel = new JLabel("건");
        unitLabel.setFont(buttonFont);
        taskPanel.add(taskField);
        taskPanel.add(unitLabel);
        mainPanel.add(taskPanel, gbc);

        // 2. 업무 강도
        gbc.gridy++;
        JLabel intensityLabel = new JLabel("업무의 강도는 어떤 정도인가요?");
        intensityLabel.setFont(labelFont);
        mainPanel.add(intensityLabel, gbc);

        gbc.gridy++;
        JSlider intensitySlider = new JSlider(0, 2, 1);
        intensitySlider.setMajorTickSpacing(1);
        intensitySlider.setPaintTicks(true);
        intensitySlider.setPaintLabels(true);
        intensitySlider.setOpaque(false);
        Hashtable<Integer, JLabel> sliderLabels = new Hashtable<>();
        sliderLabels.put(0, new JLabel("매우 낮음"));
        sliderLabels.put(1, new JLabel("보통"));
        sliderLabels.put(2, new JLabel("매우 높음"));
        sliderLabels.forEach((k, v) -> v.setFont(buttonFont));
        intensitySlider.setLabelTable(sliderLabels);
        mainPanel.add(intensitySlider, gbc);

        // 3. 회의 여부 및 개수
        gbc.gridy++;
        JLabel meetingLabel = new JLabel("남은 회의가 있나요?");
        meetingLabel.setFont(labelFont);
        mainPanel.add(meetingLabel, gbc);

        gbc.gridy++;
        JPanel meetingPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        meetingPanel.setBackground(mainPanel.getBackground());
        JRadioButton meetingYes = new JRadioButton("있어요");
        JRadioButton meetingNo = new JRadioButton("없어요");
        meetingYes.setFont(buttonFont);
        meetingNo.setFont(buttonFont);
        meetingYes.setBackground(mainPanel.getBackground());
        meetingNo.setBackground(mainPanel.getBackground());
        ButtonGroup meetingGroup = new ButtonGroup();
        meetingGroup.add(meetingYes);
        meetingGroup.add(meetingNo);
        meetingPanel.add(meetingYes);
        meetingPanel.add(meetingNo);
        mainPanel.add(meetingPanel, gbc);

        gbc.gridy++;
        JComboBox<String> meetingCountCombo = new JComboBox<>(new String[]{"1건", "2건", "3건", "4건", "5건"});
        meetingCountCombo.setEnabled(false);
        meetingCountCombo.setFont(buttonFont);
        meetingCountCombo.setPreferredSize(new Dimension(100, 25));
        mainPanel.add(meetingCountCombo, gbc);

        meetingYes.addActionListener(e -> meetingCountCombo.setEnabled(true));
        meetingNo.addActionListener(e -> meetingCountCombo.setEnabled(false));

        // 4. 상사 기분
        gbc.gridy++;
        JLabel bossMoodLabel = new JLabel("상사의 기분은 어떤가요?");
        bossMoodLabel.setFont(labelFont);
        mainPanel.add(bossMoodLabel, gbc);

        gbc.gridy++;
        JPanel moodPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        moodPanel.setBackground(mainPanel.getBackground());
        JRadioButton verygood = new JRadioButton("아주 좋음");
        JRadioButton good = new JRadioButton("좋음");
        JRadioButton average = new JRadioButton("보통");
        JRadioButton bad = new JRadioButton("나쁨");
        verygood.setFont(buttonFont); good.setFont(buttonFont);
        average.setFont(buttonFont); bad.setFont(buttonFont);
        verygood.setBackground(mainPanel.getBackground());
        good.setBackground(mainPanel.getBackground());
        average.setBackground(mainPanel.getBackground());
        bad.setBackground(mainPanel.getBackground());
        ButtonGroup moodGroup = new ButtonGroup();
        moodGroup.add(verygood); moodGroup.add(good);
        moodGroup.add(average); moodGroup.add(bad);
        moodPanel.add(verygood); moodPanel.add(good);
        moodPanel.add(average); moodPanel.add(bad);
        mainPanel.add(moodPanel, gbc);

        // 아래 여백 확보
        gbc.gridy++;
        gbc.weighty = 1;
        gbc.fill = GridBagConstraints.VERTICAL;
        mainPanel.add(Box.createVerticalGlue(), gbc);

        // 제출 버튼
        gbc.gridy++;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.SOUTHEAST;
        JButton submitButton = new JButton("입력 완료");
        submitButton.setFont(buttonFont);
        submitButton.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "입력이 완료되었습니다."); // 확인 모달
            new RoutineRecommendationUI().setVisible(true); // OK 누르면 루틴 추천 페이지로 이동
            dispose(); // 현재 창 닫기
        });

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setBackground(mainPanel.getBackground());
        buttonPanel.add(submitButton);

        gbc.gridx = 1;
        mainPanel.add(buttonPanel, gbc);

        add(mainPanel);
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(WorkStatusUI::new);
    }
}
