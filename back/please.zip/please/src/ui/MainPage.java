package ui;

import javax.swing.*;
import java.awt.*;
import ui.LoginPage;
import ui.SignUpPage;


public class MainPage extends JFrame {

    public MainPage() {
        setTitle("GOODBYE OFFICE");

        setExtendedState(JFrame.MAXIMIZED_BOTH); // 전체화면
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        Toolkit toolkit = Toolkit.getDefaultToolkit();
        Dimension screenSize = toolkit.getScreenSize();
        setSize(screenSize.width, screenSize.height);

        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(new Color(13, 39, 84));
        mainPanel.setLayout(null);
        add(mainPanel);

        JLabel titleLabel = new JLabel("GOODBYE-OFFICE", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Pretendard", Font.BOLD, 60));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBounds(0, 100, screenSize.width, 70);
        mainPanel.add(titleLabel);

        JSeparator separator = new JSeparator();
        separator.setForeground(Color.WHITE);
        separator.setBounds(screenSize.width / 4, 180, screenSize.width / 2, 2);
        mainPanel.add(separator);

        JLabel descLabel = new JLabel(
                "<html><div style='text-align: center;'>오늘 하루, 어땠나요?<br>간단한 입력만으로<br>퇴근 시간과 당신에게 꼭 맞는 마무리 루틴을 추천해드릴게요.</div></html>",
                SwingConstants.CENTER);
        descLabel.setFont(new Font("Pretendard", Font.PLAIN, 20));
        descLabel.setForeground(new Color(255, 244, 225));
        descLabel.setBounds(0, 210, screenSize.width, 120);
        mainPanel.add(descLabel);

        JLabel routineLabel = new JLabel("루틴 추천", SwingConstants.CENTER);
        routineLabel.setFont(new Font("Pretendard", Font.PLAIN, 22));
        routineLabel.setForeground(new Color(255, 244, 225));
        routineLabel.setBounds(0, 400, screenSize.width, 30);
        mainPanel.add(routineLabel);

        JButton startButton = new JButton("지금 시작하기");
        startButton.setFont(new Font("Pretendard", Font.PLAIN, 18));
        startButton.setBackground(new Color(255, 244, 225));
        startButton.setForeground(new Color(13, 39, 84));
        startButton.setFocusPainted(false);
        startButton.setBounds(screenSize.width / 2 - 100, 450, 200, 50);
        startButton.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        mainPanel.add(startButton);

        // 버튼 액션: 로그인 or 회원가입 선택
        startButton.addActionListener(e -> {
            Object[] options = { "로그인할래요", "회원가입할래요" };
            int choice = JOptionPane.showOptionDialog(
                    this,
                    "처음이신가요?",
                    "시작하기",
                    JOptionPane.YES_NO_OPTION,
                    JOptionPane.QUESTION_MESSAGE,
                    null,
                    options,
                    options[0]);

            if (choice == JOptionPane.YES_OPTION) {
                new LoginPage().setVisible(true);
                dispose();
            } else if (choice == JOptionPane.NO_OPTION) {
                new SignUpPage().setVisible(true);
                dispose();
            }
        });
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainPage().setVisible(true));
    }
}
