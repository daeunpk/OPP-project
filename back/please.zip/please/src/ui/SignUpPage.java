package ui;

import model.User;
import service.UserService;
import ui.UserStatusUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SignUpPage extends JFrame {

    private JTextField nameField, employeeIdField, phoneField, emailField;
    private UserService userService = new UserService();

    public SignUpPage() {
        setTitle("회원가입");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(13, 39, 84));
        panel.setLayout(null);

        int frameWidth = Toolkit.getDefaultToolkit().getScreenSize().width;

        JLabel titleLabel = new JLabel("회원가입");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBounds((frameWidth - 250) / 2, 80, 250, 30);
        panel.add(titleLabel);

        nameField = new JTextField(); nameField.setBounds(700, 150, 500, 40); panel.add(nameField);
        employeeIdField = new JTextField(); employeeIdField.setBounds(700, 210, 500, 40); panel.add(employeeIdField);
        phoneField = new JTextField(); phoneField.setBounds(700, 270, 500, 40); panel.add(phoneField);
        emailField = new JTextField(); emailField.setBounds(700, 330, 500, 40); panel.add(emailField);

        JLabel nameLabel = new JLabel("이름:"); nameLabel.setBounds(620, 150, 100, 40); nameLabel.setForeground(Color.WHITE); panel.add(nameLabel);
        JLabel idLabel = new JLabel("사번:"); idLabel.setBounds(620, 210, 100, 40); idLabel.setForeground(Color.WHITE); panel.add(idLabel);
        JLabel phoneLabel = new JLabel("전화번호:"); phoneLabel.setBounds(620, 270, 100, 40); phoneLabel.setForeground(Color.WHITE); panel.add(phoneLabel);
        JLabel emailLabel = new JLabel("이메일:"); emailLabel.setBounds(620, 330, 100, 40); emailLabel.setForeground(Color.WHITE); panel.add(emailLabel);

        JButton signupButton = new JButton("회원가입");
        signupButton.setBounds(850, 400, 100, 40);
        panel.add(signupButton);

        add(panel);
        setVisible(true);

        // 💡 기능 연결: 회원가입 버튼 누르면 UserService 호출
        signupButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String name = nameField.getText().trim();
                String id = employeeIdField.getText().trim();
                String phone = phoneField.getText().trim();
                String email = emailField.getText().trim();

                if (name.isEmpty() || id.isEmpty() || phone.isEmpty() || email.isEmpty()) {
                    JOptionPane.showMessageDialog(SignUpPage.this, "모든 정보를 입력해주세요.");
                    return;
                }

                User user = new User(name, id, phone, email);
                boolean success = userService.register(user);

                if (success) {
                    JOptionPane.showMessageDialog(SignUpPage.this, "회원가입 성공!");
                    dispose();
                    new UserStatusUI(); // 👉 다음 화면으로 이동
                } else {
                    JOptionPane.showMessageDialog(SignUpPage.this, "이미 존재하는 사번입니다.");
                }
            }
        });
    }
}
