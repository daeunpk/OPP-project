package ui;

// encoding: UTF-8
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.List;
import ui.MainPage;

public class MyPageUI extends JFrame {
    private JComboBox<String> weekSelector;
    private JComboBox<String> monthSelector;
    private DefaultListModel<String> dateListModel;
    private JTextArea routineDetailArea;
    private JLabel nameLabel, idLabel, phoneLabel, emailLabel;

    private final Map<LocalDate, LocalTime> weeklyTimes = new LinkedHashMap<>() {{
        put(LocalDate.of(2025, 5, 11), LocalTime.of(15, 0));
        put(LocalDate.of(2025, 5, 12), LocalTime.of(20, 45));
        put(LocalDate.of(2025, 5, 13), LocalTime.of(18, 25));
        put(LocalDate.of(2025, 5, 14), LocalTime.of(20, 13));
        put(LocalDate.of(2025, 5, 15), LocalTime.of(22, 0));
        put(LocalDate.of(2025, 5, 16), LocalTime.of(18, 0));
        put(LocalDate.of(2025, 5, 17), LocalTime.of(0, 0));
    }};

    public MyPageUI() {
        setTitle("마이페이지 - GOODBYE-OFFICE");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(4, 36, 74));

        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(4, 36, 74));
        JLabel titleLabel = new JLabel("개인 정보 설정");
        titleLabel.setFont(new Font("Malgun Gothic", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBorder(new EmptyBorder(20, 20, 10, 10));
        headerPanel.add(titleLabel, BorderLayout.NORTH);

        JPanel separator = new JPanel();
        separator.setBackground(Color.WHITE);
        separator.setPreferredSize(new Dimension(1, 2));
        headerPanel.add(separator, BorderLayout.SOUTH);

        JButton homeButton = new JButton("홈");
        homeButton.setFont(new Font("Malgun Gothic", Font.PLAIN, 18));
        homeButton.setContentAreaFilled(false);
        homeButton.setBorderPainted(false);
        homeButton.setForeground(Color.WHITE);
        homeButton.addActionListener(e -> {
            new MainPage().setVisible(true);
            dispose();
        });
        headerPanel.add(homeButton, BorderLayout.WEST);
        mainPanel.add(headerPanel, BorderLayout.NORTH);

        JPanel contentPanel = new JPanel(new BorderLayout());
        contentPanel.setBackground(new Color(4, 36, 74));

        JPanel leftPanel = createProfilePanel();
        JPanel rightPanel = createInfoPanels();

        contentPanel.add(leftPanel, BorderLayout.WEST);
        contentPanel.add(rightPanel, BorderLayout.CENTER);

        mainPanel.add(contentPanel, BorderLayout.CENTER);
        add(mainPanel);
        setVisible(true);
    }

    private JPanel createProfilePanel() {
        JPanel panel = new JPanel();
        panel.setBackground(new Color(4, 36, 74));
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(new EmptyBorder(30, 30, 30, 30));

        nameLabel = createLabel("이름: 김다은");
        idLabel = createLabel("사번: 20250612");
        phoneLabel = createLabel("전화번호: 01012345678");
        emailLabel = createLabel("이메일: daeun.kim@example.com");
        JLabel joinLabel = createLabel("가입일: 2025-01-19");

        panel.add(nameLabel);
        panel.add(idLabel);
        panel.add(phoneLabel);
        panel.add(emailLabel);
        panel.add(joinLabel);

        JPanel buttonBox = new JPanel();
        buttonBox.setBackground(new Color(4, 36, 74));
        buttonBox.setLayout(new BoxLayout(buttonBox, BoxLayout.Y_AXIS));
        buttonBox.setBorder(BorderFactory.createLineBorder(Color.WHITE));

        JButton editBtn = new JButton("회원정보 수정");
        JButton deleteBtn = new JButton("회원 탈퇴");
        buttonBox.add(editBtn);
        buttonBox.add(Box.createVerticalStrut(10));
        buttonBox.add(deleteBtn);
        panel.add(Box.createVerticalStrut(30));
        panel.add(buttonBox);

        editBtn.addActionListener(e -> {
            String newName = JOptionPane.showInputDialog("이름 수정:", nameLabel.getText().substring(4));
            if (newName != null) nameLabel.setText("이름: " + newName);
        });

        return panel;
    }

    private JPanel createInfoPanels() {
        JPanel wrapper = new JPanel();
        wrapper.setBackground(new Color(4, 36, 74));
        wrapper.setLayout(new GridLayout(2, 1, 10, 10));
        wrapper.setBorder(new EmptyBorder(20, 20, 20, 20));

        wrapper.add(createChartBox());
        wrapper.add(createHistoryBox());
        return wrapper;
    }

    private JPanel createChartBox() {
        JPanel box = new JPanel(new BorderLayout());
        box.setBackground(new Color(4, 36, 74));
        box.setBorder(BorderFactory.createLineBorder(Color.WHITE));

        JLabel chartTitle = new JLabel("일일 퇴근 시간 19:03");
        chartTitle.setForeground(Color.WHITE);
        chartTitle.setFont(new Font("Malgun Gothic", Font.BOLD, 16));

        weekSelector = new JComboBox<>(new String[]{"20250511~20250517"});
        weekSelector.setFont(new Font("Malgun Gothic", Font.PLAIN, 12));

        JPanel top = new JPanel(new BorderLayout());
        top.setBackground(new Color(4, 36, 74));
        top.add(chartTitle, BorderLayout.WEST);
        top.add(weekSelector, BorderLayout.EAST);

        box.add(top, BorderLayout.NORTH);

        JPanel chartPanel = new JPanel() {
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g;
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                int w = getWidth(), h = getHeight();
                int margin = 40;

                g2.setColor(Color.WHITE);
                g2.drawLine(margin, h - margin, w - margin, h - margin); // X축
                g2.drawLine(margin, margin, margin, h - margin);         // Y축

                List<LocalDate> days = new ArrayList<>(weeklyTimes.keySet());
                int n = days.size();
                int xGap = (w - 2 * margin) / (n - 1);

                int[] xPoints = new int[n];
                int[] yPoints = new int[n];

                g2.setColor(Color.CYAN);
                g2.setStroke(new BasicStroke(2));

                for (int i = 0; i < n; i++) {
                    LocalTime t = weeklyTimes.get(days.get(i));
                    double hours = t.getHour() + t.getMinute() / 60.0;
                    int x = margin + i * xGap;
                    int y = h - margin - (int) ((hours - 15) * 20);
                    xPoints[i] = x;
                    yPoints[i] = y;
                    g2.fillOval(x - 4, y - 4, 8, 8);
                    g2.drawString(String.format("%02d:%02d", t.getHour(), t.getMinute()), x - 15, y - 10);
                    g2.drawString(days.get(i).getDayOfWeek().toString().substring(0,1), x - 5, h - margin + 15);
                }
                g2.drawPolyline(xPoints, yPoints, n);
            }
        };
        chartPanel.setPreferredSize(new Dimension(500, 200));
        chartPanel.setBackground(new Color(4, 36, 74));
        box.add(chartPanel, BorderLayout.CENTER);
        return box;
    }

    private JPanel createHistoryBox() {
        JPanel box = new JPanel(new BorderLayout());
        box.setBackground(new Color(4, 36, 74));
        box.setBorder(BorderFactory.createLineBorder(Color.WHITE));

        JLabel historyTitle = new JLabel("루틴 추천 히스토리");
        historyTitle.setForeground(Color.WHITE);
        historyTitle.setFont(new Font("Malgun Gothic", Font.BOLD, 16));
        box.add(historyTitle, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.setBackground(new Color(4, 36, 74));

        JPanel listPanel = new JPanel(new BorderLayout());
        listPanel.setBackground(new Color(4, 36, 74));
        monthSelector = new JComboBox<>(new String[]{"2025-05월"});
        monthSelector.setFont(new Font("Malgun Gothic", Font.PLAIN, 12));
        listPanel.add(monthSelector, BorderLayout.NORTH);

        dateListModel = new DefaultListModel<>();
        for (int i = 11; i <= 17; i++) dateListModel.addElement("2025년 5월 " + i + "일");

        JList<String> dateList = new JList<>(dateListModel);
        dateList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        dateList.setBackground(new Color(230, 230, 250));
        dateList.setFont(new Font("Malgun Gothic", Font.PLAIN, 13));
        dateList.addListSelectionListener(e -> {
            String selected = dateList.getSelectedValue();
            routineDetailArea.setText("선택된 날짜: " + selected + "\n\n21:25 DINNER\n우삼겹 덮밥\n\n22:25 CONTENT TIME\n스포티파이 음악감상\n\n23:45 WIND DOWN\n마사지건 + 스트레칭\n\n00:25 WRAP UP\n핸드크림 바르고 독서");
        });
        JScrollPane dateScroll = new JScrollPane(dateList);
        listPanel.add(dateScroll, BorderLayout.CENTER);
        centerPanel.add(listPanel, BorderLayout.WEST);

        routineDetailArea = new JTextArea("날짜를 선택해주세요.");
        routineDetailArea.setLineWrap(true);
        routineDetailArea.setWrapStyleWord(true);
        routineDetailArea.setFont(new Font("Malgun Gothic", Font.PLAIN, 14));
        routineDetailArea.setEditable(false);
        JScrollPane detailScroll = new JScrollPane(routineDetailArea);
        centerPanel.add(detailScroll, BorderLayout.CENTER);

        box.add(centerPanel, BorderLayout.CENTER);
        return box;
    }

    private JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(Color.WHITE);
        label.setFont(new Font("Malgun Gothic", Font.PLAIN, 16));
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        label.setBorder(new EmptyBorder(5, 0, 5, 0));
        return label;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(MyPageUI::new);
    }
}
