package ui;

public class RoutineDoneMain {
    public static void main(String[] args) {
        new RoutineResultPage(); // 루틴 추천부터 시작
    }
}
