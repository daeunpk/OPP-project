package ui;

import model.User;
import service.UserService;
import ui.UserStatusUI;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LoginPage extends JFrame {

    private JTextField employeeIdField;
    private UserService userService = new UserService();

    public LoginPage() {
        setTitle("로그인");

        setExtendedState(JFrame.MAXIMIZED_BOTH); // 전체화면
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(13, 39, 84));
        panel.setLayout(null);

        int frameWidth = Toolkit.getDefaultToolkit().getScreenSize().width;

        JLabel titleLabel = new JLabel("GOODBYE-OFFICE");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBounds((frameWidth - 250) / 2, 80, 250, 30);
        panel.add(titleLabel);

        JLabel idLabel = new JLabel("사번:");
        idLabel.setBounds(620, 200, 100, 40);
        idLabel.setForeground(Color.WHITE);
        panel.add(idLabel);

        employeeIdField = new JTextField();
        employeeIdField.setBounds(700, 200, 500, 40);
        panel.add(employeeIdField);

        JButton loginButton = new JButton("로그인 하기");
        loginButton.setBounds(850, 270, 150, 40);
        panel.add(loginButton);

        add(panel);
        setVisible(true);

        // 💡 기능 연결: 로그인 버튼
        loginButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String id = employeeIdField.getText().trim();
                if (id.isEmpty()) {
                    JOptionPane.showMessageDialog(LoginPage.this, "사번을 입력해주세요.");
                    return;
                }

                User user = userService.login(id);
                if (user != null) {
                    JOptionPane.showMessageDialog(LoginPage.this, user.getName() + "님, 환영합니다!");
                    dispose();
                    new UserStatusUI(); // 👉 다음 화면으로 이동
                } else {
                    JOptionPane.showMessageDialog(LoginPage.this, "존재하지 않는 사번입니다.");
                }
            }
        });
    }
}