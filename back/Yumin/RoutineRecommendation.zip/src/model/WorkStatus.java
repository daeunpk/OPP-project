package model;

import java.io.Serializable;

public class WorkStatus implements Serializable {
    private int taskCount;          // 남은 업무 개수
    private int taskIntensity;      // 업무 강도 0~10
    private boolean hasMeeting;     // 회의 있음/없음
    private int meetingCount;       // 회의 개수
    private String bossMood;        // 😀~😡

    public WorkStatus(int taskCount, int taskIntensity, boolean hasMeeting, int meetingCount, String bossMood) {
        this.taskCount = taskCount;
        this.taskIntensity = taskIntensity;
        this.hasMeeting = hasMeeting;
        this.meetingCount = meetingCount;
        this.bossMood = bossMood;
    }

    public int getTaskCount() { return taskCount; }
    public int getTaskIntensity() { return taskIntensity; }
    public boolean isHasMeeting() { return hasMeeting; }
    public int getMeetingCount() { return meetingCount; }
    public String getBossMood() { return bossMood; }

    @Override
    public String toString() {
        return "WorkStatus{" +
                "taskCount=" + taskCount +
                ", taskIntensity=" + taskIntensity +
                ", hasMeeting=" + hasMeeting +
                ", meetingCount=" + meetingCount +
                ", bossMood='" + bossMood + '\'' +
                '}';
    }
}
