package service;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import model.User;

import java.io.*;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class UserService {
    private static final String FILE_PATH = System.getProperty("user.dir") + "/storage/users.json";
    private List<User> userList;

    public UserService() {
        userList = loadUsers();
    }

    private List<User> loadUsers() {
        File file = new File(FILE_PATH);
        if (!file.exists()) {
            System.out.println("[로그] users.json 파일이 존재하지 않습니다. 새로 생성됩니다.");
            return new ArrayList<>();
        }

        try (Reader reader = new FileReader(file)) {
            Type listType = new TypeToken<ArrayList<User>>() {}.getType();
            List<User> loaded = new Gson().fromJson(reader, listType);
            System.out.println("[로그] 사용자 목록 불러오기 성공: " + loaded.size() + "명");
            return loaded;
        } catch (IOException e) {
            System.err.println("[에러] 사용자 불러오기 실패");
            e.printStackTrace();
            return new ArrayList<>();
        }
    }

    private void saveUsers() {
        try {
            // 폴더가 없으면 만들어주기
            File file = new File(FILE_PATH);
            file.getParentFile().mkdirs();

            try (Writer writer = new FileWriter(file)) {
                Gson gson = new GsonBuilder().setPrettyPrinting().create();
                gson.toJson(userList, writer);
                System.out.println("[로그] 사용자 저장 완료: " + file.getAbsolutePath());
            }
        } catch (IOException e) {
            System.err.println("[에러] 사용자 저장 실패");
            e.printStackTrace();
        }
    }

    public boolean registerUser(User newUser) {
        for (User u : userList) {
            if (u.getEmID().equals(newUser.getEmID())) {
                return false; // 중복 사번
            }
        }
        userList.add(newUser);
        saveUsers();
        System.out.println("[로그] 회원가입 저장 완료: " + newUser.getName());
        return true;
    }

    public boolean validateLogin(String empId, String name) {
        for (User u : userList) {
            if (u.getEmID().equals(empId) && u.getName().equals(name)) {
                return true;
            }
        }
        return false;
    }

    public User getUser(String empId) {
        for (User u : userList) {
            if (u.getEmID().equals(empId)) return u;
        }
        return null;
    }
}
