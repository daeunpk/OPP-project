// encoding: UTF-8
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicSliderUI;
import java.awt.*;
import java.util.Hashtable;
import model.*;
import service.*;
import java.time.LocalTime;


public class WorkStatusUI extends JFrame {
	private UserStatus userStatus;

    public WorkStatusUI(UserStatus userStatus) {
        setTitle("GOODBYE-OFFICE");
		
		setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
		getContentPane().setBackground(new Color(250, 240, 230));
        setLayout(new BorderLayout());
		
		int frameWidth = Toolkit.getDefaultToolkit().getScreenSize().width;
		
		// 상단 바
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(new Color(250, 240, 230));
        topPanel.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(0x4E4E4E)));
		topPanel.setBounds(0, 0, frameWidth, 80);
		
        JLabel topTitleLabel = new JLabel("오늘 업무는 몇 시에 끝날까요?");
        topTitleLabel.setForeground(new Color(0x4E4E4E));
        topTitleLabel.setFont(new Font("Pretendard", Font.BOLD, 30));
        topTitleLabel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 0));
        topPanel.add(topTitleLabel, BorderLayout.WEST);
		
		// 오른쪽 버튼 패널
		JButton myPageButton = new JButton("\u2699");
		myPageButton.setFont(new Font("Pretendard", Font.BOLD, 40));
		myPageButton.setBackground(new Color(250, 240, 230));
		myPageButton.setForeground(new Color(13, 39, 84));
		myPageButton.setFocusPainted(false);
		myPageButton.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
		myPageButton.addActionListener(e -> {
			new MyPageUI().setVisible(true);
			dispose();
		});
		
		JButton homeButton = new JButton("\u2302");
		homeButton.setFont(new Font("Pretendard", Font.BOLD, 40));
		homeButton.setBackground(new Color(250, 240, 230));
		homeButton.setForeground(new Color(13, 39, 84));
		homeButton.setFocusPainted(false);
		homeButton.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
		homeButton.addActionListener(e -> {
			new MainPage().setVisible(true);
			dispose();
		});
		
		JPanel rightButtonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
		rightButtonPanel.setOpaque(false);
		rightButtonPanel.add(myPageButton);
		rightButtonPanel.add(homeButton);
		
		topPanel.add(rightButtonPanel, BorderLayout.EAST);
        add(topPanel, BorderLayout.NORTH);
		
		// 중앙 컨텐츠 패널
		JPanel contentPanel = new JPanel();
        contentPanel.setBackground(new Color(250, 240, 230));
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBorder(new EmptyBorder(40, 100, 40, 100));
		
        // 남은 업무 개수
        JPanel taskBlock = new JPanel();
        taskBlock.setLayout(new BoxLayout(taskBlock, BoxLayout.Y_AXIS));
        taskBlock.setOpaque(false);
        taskBlock.setBorder(new EmptyBorder(20, 0, 30, 0));
		
		JLabel taskLabel = new JLabel("남은 업무는 몇 개인가요?");
		taskLabel.setFont(new Font("Pretendard", Font.PLAIN, 26));
		taskLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        taskBlock.add(taskLabel);
		
		taskBlock.add(Box.createVerticalStrut(15));
		
        JPanel taskPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		taskPanel.setOpaque(false);
        JTextField taskField = new JTextField();
        taskField.setPreferredSize(new Dimension(150, 30));
        taskField.setHorizontalAlignment(JTextField.CENTER);
		taskField.setFont(new Font("Pretendard", Font.PLAIN, 20));
        JLabel unitLabel = new JLabel("건");
        unitLabel.setFont(new Font("Pretendard", Font.PLAIN, 22));
        taskPanel.add(taskField);
        taskPanel.add(unitLabel);
		
		taskBlock.add(taskPanel);
        contentPanel.add(taskBlock);

        // 업무 강도
        JPanel intensityBlock = new JPanel();
        intensityBlock.setLayout(new BoxLayout(intensityBlock, BoxLayout.Y_AXIS));
        intensityBlock.setOpaque(false);
        intensityBlock.setBorder(new EmptyBorder(30, 0, 30, 0));
		
		JLabel intensityLabel = new JLabel("업무의 강도는 어떤 정도인가요?");
        intensityLabel.setFont(new Font("Pretendard", Font.PLAIN, 26));
		intensityLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        contentPanel.add(intensityLabel);
		
		intensityBlock.add(Box.createVerticalStrut(10));
		
        JSlider intensitySlider = new JSlider(0, 2, 1);
		intensitySlider.setUI(new CustomSliderUI(intensitySlider));
        intensitySlider.setMajorTickSpacing(1);
        intensitySlider.setPaintTicks(false);
        intensitySlider.setPaintLabels(true);
        intensitySlider.setOpaque(false);
        Hashtable<Integer, JLabel> sliderLabels = new Hashtable<>();
        sliderLabels.put(0, new JLabel("매우 낮음"));
        sliderLabels.put(1, new JLabel("보통"));
        sliderLabels.put(2, new JLabel("매우 높음"));
		Color labelColor = new Color(0x4E4E4E);
        sliderLabels.forEach((k, v) -> {
			v.setFont(new Font("Pretendard", Font.PLAIN, 18));
			v.setForeground(labelColor);
		});
        intensitySlider.setLabelTable(sliderLabels);
		intensitySlider.setPreferredSize(new Dimension(1000, 60));
        intensityBlock.add(Box.createRigidArea(new Dimension(0, 10)));
        intensityBlock.add(intensitySlider);
        contentPanel.add(intensityBlock);

        // 회의 여부 및 개수
        JPanel meetingBlock = new JPanel();
        meetingBlock.setLayout(new BoxLayout(meetingBlock, BoxLayout.Y_AXIS));
        meetingBlock.setOpaque(false);
		meetingBlock.setBorder(new EmptyBorder(30, 0, 30, 0));
		
		JLabel meetingLabel = new JLabel("남은 회의가 있나요?");
        meetingLabel.setFont(new Font("Pretendard", Font.PLAIN, 26));
		meetingLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        meetingBlock.add(meetingLabel);
		
		meetingBlock.add(Box.createVerticalStrut(15));
		
		JRadioButton meetingYes = new JRadioButton("있어요");
        JRadioButton meetingNo = new JRadioButton("없어요");
        meetingYes.setFont(new Font("Pretendard", Font.PLAIN, 20));
        meetingNo.setFont(new Font("Pretendard", Font.PLAIN, 20));
		meetingYes.setBorder(BorderFactory.createEmptyBorder(8, 32, 8, 32));
		meetingNo.setBorder(BorderFactory.createEmptyBorder(8, 32, 8, 32));
		
        ButtonGroup meetingGroup = new ButtonGroup();
        meetingGroup.add(meetingYes);
        meetingGroup.add(meetingNo);

        ImageIcon radioIcon = new ImageIcon(getClass().getResource("/icons/radio_unchecked.png"));
        ImageIcon radioSelectedIcon = new ImageIcon(getClass().getResource("/icons/radio_checked.png"));

		for (JRadioButton btn : new JRadioButton[]{meetingYes, meetingNo}) {
			btn.setOpaque(false);	btn.setContentAreaFilled(false);	btn.setBorderPainted(false);
			btn.setIcon(radioIcon);
			btn.setSelectedIcon(radioSelectedIcon);
			btn.setIconTextGap(12);
			btn.setBorder(BorderFactory.createEmptyBorder(8, 20, 8, 20));
		}
		
		JComboBox<String> meetingCountCombo = new JComboBox<>(new String[]{"1건", "2건", "3건", "4건", "5건"});
        meetingCountCombo.setEnabled(false);
        meetingCountCombo.setFont(new Font("Pretendard", Font.BOLD, 20));
        meetingCountCombo.setPreferredSize(new Dimension(100, 40));
		meetingCountCombo.setBackground(new Color(255, 255, 255));
		meetingCountCombo.setForeground(new Color(0x4E4E4E));
		
		DefaultListCellRenderer renderer = new DefaultListCellRenderer();
		renderer.setHorizontalAlignment(SwingConstants.CENTER);
		meetingCountCombo.setRenderer(renderer);
		
		JPanel yesComboPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
		yesComboPanel.setOpaque(false);
        yesComboPanel.add(meetingYes);
        yesComboPanel.add(meetingCountCombo);
		
		JPanel meetingRadioPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 40, 0));
		meetingRadioPanel.setOpaque(false);
		meetingRadioPanel.add(yesComboPanel);
		meetingRadioPanel.add(meetingNo);
		meetingBlock.add(meetingRadioPanel);
		
        meetingYes.addActionListener(e -> meetingCountCombo.setEnabled(true));
        meetingNo.addActionListener(e -> meetingCountCombo.setEnabled(false));
		
		contentPanel.add(meetingBlock);
		
        // 상사 기분
        JPanel bossMoodBlock = new JPanel();
        bossMoodBlock.setLayout(new BoxLayout(bossMoodBlock, BoxLayout.Y_AXIS));
        bossMoodBlock.setOpaque(false);
        bossMoodBlock.setBorder(new EmptyBorder(30, 0, 30, 0));
		
		JLabel bossMoodLabel = new JLabel("상사의 기분은 어떤가요?");
        bossMoodLabel.setFont(new Font("Pretendard", Font.PLAIN, 26));
		bossMoodLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        bossMoodBlock.add(bossMoodLabel);
		
		bossMoodBlock.add(Box.createVerticalStrut(15));
		
		JPanel bossMoodPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 36, 0));
		bossMoodPanel.setOpaque(false);
		
		JRadioButton verygood = new JRadioButton("😀");
		JRadioButton good = new JRadioButton("🙂");
		JRadioButton average = new JRadioButton("☹");
		JRadioButton bad = new JRadioButton("️😫");

		JRadioButton[] moodButtons = {verygood, good, average, bad};
		ButtonGroup moodGroup = new ButtonGroup();

		for (JRadioButton btn : moodButtons) {
			btn.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 28));
			btn.setFocusPainted(false);
			btn.setOpaque(false);
			btn.setBackground(new Color(250, 240, 230));
			btn.setForeground(new Color(0x4E4E4E));
			btn.setIcon(radioIcon);
			btn.setSelectedIcon(radioSelectedIcon);
			btn.setIconTextGap(16);
			btn.setBorder(BorderFactory.createEmptyBorder(10, 40, 10, 40));

			moodGroup.add(btn);
			bossMoodPanel.add(btn);
		}
        bossMoodBlock.add(bossMoodPanel);
        contentPanel.add(bossMoodBlock);
		
        // 입력 완료 버튼
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setOpaque(false);
		JButton submitButton = new JButton("<html><center>입력 완료</center></html>");
        submitButton.setFont(new Font("Pretendard", Font.BOLD, 20));
		submitButton.setBackground(new Color(13, 39, 84));
		submitButton.setForeground(new Color(250, 240, 230));
        submitButton.setFocusPainted(false);
		submitButton.setPreferredSize(new Dimension(180, 50));
		buttonPanel.add(submitButton);
        buttonPanel.setBorder(new EmptyBorder(30, 0, 0, 0));
        contentPanel.add(buttonPanel);
		
        submitButton.addActionListener(e -> {
            try {
                // 1. 사용자 입력값 수집
                int taskCount = Integer.parseInt(taskField.getText().trim()); // 남은 업무 개수
                int taskIntensity = intensitySlider.getValue() * 5; // 0~2 → 0, 5, 10으로 보정

                boolean hasMeeting = meetingYes.isSelected();
                int meetingCount = hasMeeting
                        ? Integer.parseInt(meetingCountCombo.getSelectedItem().toString().replace("건", ""))
                        : 0;

                String bossMood = verygood.isSelected() ? "😀" :
                        good.isSelected()     ? "😊" :
                                average.isSelected()  ? "😐" :
                                        bad.isSelected()      ? "😡" : "😐"; // default는 보통

                // 2. WorkStatus 객체 생성
                WorkStatus workStatus = new WorkStatus(taskCount, taskIntensity, hasMeeting, meetingCount, bossMood);

                // 3. 퇴근 시간 계산 (기준은 현재 시간 또는 18:00)
                LocalTime baseTime = LocalTime.of(18, 0);
                LocalTime predictedEndTime = WorkStatusCalculator.calculateEndTime(baseTime, workStatus);

                // 4. 루틴 추천 화면으로 이동
                JOptionPane.showMessageDialog(this, "입력이 완료되었습니다.");
                new RoutineRecommendationUI(userStatus, predictedEndTime).setVisible(true);
                dispose();

				} catch (Exception ex) {
					JOptionPane.showMessageDialog(this, "모든 값을 올바르게 입력해주세요.", "입력 오류", JOptionPane.ERROR_MESSAGE);
				}
			});

			add(contentPanel, BorderLayout.CENTER);
		}

		
		public static class CustomSliderUI extends BasicSliderUI {
        public CustomSliderUI(JSlider slider) {
            super(slider);
        }

        @Override
        public void paintTrack(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int trackWidth = trackRect.width;
            int trackHeight = 20;
            int trackX = trackRect.x + (trackRect.width - trackWidth) / 2;
            int trackY = trackRect.y + (trackRect.height - trackHeight) / 2;
            g2.setColor(new Color(220, 220, 220));
            g2.fillRoundRect(trackX, trackY, trackWidth, trackHeight, trackHeight, trackHeight);
            int value = slider.getValue();
            int min = slider.getMinimum();
            int max = slider.getMaximum();
            int fillWidth = (int) ((value - min) * (trackWidth * 1.0 / (max - min)));
            g2.setColor(new Color(13, 39, 84));
            g2.fillRoundRect(trackX, trackY, fillWidth, trackHeight, trackHeight, trackHeight);
        }

        @Override
        public void paintThumb(Graphics g) {
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int thumbRadius = 20;
            int x = thumbRect.x + thumbRect.width / 2 - thumbRadius / 2;
            int y = thumbRect.y + thumbRect.height / 2 - thumbRadius / 2;
            g2.setColor(Color.WHITE);
            g2.fillOval(x, y, thumbRadius, thumbRadius);
            g2.setColor(new Color(13, 39, 84));
            g2.setStroke(new BasicStroke(2));
            g2.drawOval(x, y, thumbRadius, thumbRadius);
        }

        @Override
        protected Dimension getThumbSize() {
            return new Dimension(20, 20);
        }
    }
}
