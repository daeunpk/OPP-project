import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicSliderUI;
import java.awt.*;
import java.util.Hashtable;
import java.time.LocalTime;
import model.*;
import service.*;


public class UserStatusUI extends JFrame {
	public UserStatusUI() {
        setTitle("GOODBYE-OFFICE");
		
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
		getContentPane().setBackground(new Color(250, 240, 230));
		setLayout(new BorderLayout());
		
		int frameWidth = Toolkit.getDefaultToolkit().getScreenSize().width;
		
		// 상단 바
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(new Color(250, 240, 230));
        topPanel.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(0x4E4E4E)));
		topPanel.setBounds(0, 0, frameWidth, 80);
		
        JLabel topTitleLabel = new JLabel("오늘 하루는 어땠나요?");
        topTitleLabel.setForeground(new Color(0x4E4E4E));
        topTitleLabel.setFont(new Font("Pretendard", Font.BOLD, 30));
        topTitleLabel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 0));
        topPanel.add(topTitleLabel, BorderLayout.WEST);
		
		// 오른쪽 버튼 패널
		JButton myPageButton = new JButton("\u2699");
		myPageButton.setFont(new Font("Pretendard", Font.BOLD, 40));
		myPageButton.setBackground(new Color(250, 240, 230));
		myPageButton.setForeground(new Color(13, 39, 84));
		myPageButton.setFocusPainted(false);
		myPageButton.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
		myPageButton.addActionListener(e -> {
			new MyPageUI().setVisible(true);
			dispose();
		});
		
		JButton homeButton = new JButton("\u2302");
		homeButton.setFont(new Font("Pretendard", Font.BOLD, 40));
		homeButton.setBackground(new Color(250, 240, 230));
		homeButton.setForeground(new Color(13, 39, 84));
		homeButton.setFocusPainted(false);
		homeButton.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
		homeButton.addActionListener(e -> {
			new MainPage().setVisible(true);
			dispose();
		});
		
		JPanel rightButtonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
		rightButtonPanel.setOpaque(false);
		rightButtonPanel.add(myPageButton);
		rightButtonPanel.add(homeButton);
		
		topPanel.add(rightButtonPanel, BorderLayout.EAST);
        add(topPanel, BorderLayout.NORTH);
		
		// 중앙 컨텐츠 패널
		JPanel contentPanel = new JPanel();
        contentPanel.setBackground(new Color(250, 240, 230));
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBorder(new EmptyBorder(40, 100, 40, 100));
		
		// 기분
        JPanel moodBlock = new JPanel();
        moodBlock.setLayout(new BoxLayout(moodBlock, BoxLayout.Y_AXIS));
        moodBlock.setOpaque(false);
        moodBlock.setBorder(new EmptyBorder(20, 0, 30, 0));
		
		JLabel moodLabel = new JLabel("오늘의 기분은 어땠나요?");
        moodLabel.setFont(new Font("Pretendard", Font.PLAIN, 26));
		moodLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        moodBlock.add(moodLabel);
		
		moodBlock.add(Box.createVerticalStrut(15));

		ImageIcon radioIcon = new ImageIcon(getClass().getResource("/icons/radio_unchecked.png"));
		ImageIcon radioSelectedIcon = new ImageIcon(getClass().getResource("/icons/radio_checked.png"));

		JPanel moodPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 36, 0));
		moodPanel.setOpaque(false);

		JRadioButton verygood = new JRadioButton("😀");
		JRadioButton good = new JRadioButton("🙂");
		JRadioButton average = new JRadioButton("☹");
		JRadioButton bad = new JRadioButton("️😫");

		JRadioButton[] moodButtons = {verygood, good, average, bad};
		ButtonGroup moodGroup = new ButtonGroup();

		for (JRadioButton btn : moodButtons) {
			btn.setFont(new Font("Segoe UI Emoji", Font.PLAIN, 28));
			btn.setFocusPainted(false);
			btn.setOpaque(false);
			btn.setBackground(new Color(250, 240, 230));
			btn.setForeground(new Color(0x4E4E4E));
			btn.setIcon(radioIcon);
			btn.setSelectedIcon(radioSelectedIcon);
			btn.setIconTextGap(16);
			btn.setBorder(BorderFactory.createEmptyBorder(10, 40, 10, 40));

			moodGroup.add(btn);
			moodPanel.add(btn);
		}
        moodBlock.add(moodPanel);
        contentPanel.add(moodBlock);
		
		// 에너지
		JPanel energyBlock = new JPanel();
        energyBlock.setLayout(new BoxLayout(energyBlock, BoxLayout.Y_AXIS));
        energyBlock.setOpaque(false);
        energyBlock.setBorder(new EmptyBorder(30, 0, 30, 0));
		
        JLabel energyLabel = new JLabel("오늘의 에너지는 어느 정도인가요?");
        energyLabel.setFont(new Font("Pretendard", Font.PLAIN, 26));
		energyLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        energyBlock.add(energyLabel);
		
		energyBlock.add(Box.createVerticalStrut(15));
		
        JSlider energySlider = new JSlider(0, 2, 1);
		energySlider.setUI(new CustomSliderUI(energySlider));
        energySlider.setMajorTickSpacing(1);
        energySlider.setPaintTicks(false);
        energySlider.setPaintLabels(true);
        energySlider.setOpaque(false);
        Hashtable<Integer, JLabel> sliderLabels = new Hashtable<>();
        sliderLabels.put(0, new JLabel("없어요"));
        sliderLabels.put(1, new JLabel("보통이에요"));
        sliderLabels.put(2, new JLabel("많아요"));
		Color labelColor = new Color(0x4E4E4E);
        sliderLabels.forEach((k, v) -> {
			v.setFont(new Font("Pretendard", Font.PLAIN, 18));
			v.setForeground(labelColor);
		});
        energySlider.setLabelTable(sliderLabels);
        energySlider.setPreferredSize(new Dimension(1000, 60));
        energyBlock.add(Box.createRigidArea(new Dimension(0, 10)));
        energyBlock.add(energySlider);
        contentPanel.add(energyBlock);
		
		// 대인 여부
		JPanel socialBlock = new JPanel();
        socialBlock.setLayout(new BoxLayout(socialBlock, BoxLayout.Y_AXIS));
        socialBlock.setOpaque(false);
        socialBlock.setBorder(new EmptyBorder(30, 0, 30, 0));
		
        JLabel socialLabel = new JLabel("퇴근 후 사람과 함께하고 싶은가요?");
        socialLabel.setFont(new Font("Pretendard", Font.PLAIN, 26));
		socialLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        socialBlock.add(socialLabel);
		
		socialBlock.add(Box.createVerticalStrut(15));
		
        JPanel socialPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 40, 10));
		socialPanel.setOpaque(false);
        JRadioButton alone = new JRadioButton("혼자 있고 싶어요");
        JRadioButton withPeople = new JRadioButton("사람들과 있고 싶어요");
        alone.setFont(new Font("Pretendard", Font.PLAIN, 20));
        withPeople.setFont(new Font("Pretendard", Font.PLAIN, 20));
		alone.setOpaque(false);	alone.setContentAreaFilled(false);	alone.setBorderPainted(false);
		withPeople.setOpaque(false); withPeople.setContentAreaFilled(false); withPeople.setBorderPainted(false);
		
		alone.setBorder(BorderFactory.createEmptyBorder(8, 32, 8, 32));
		withPeople.setBorder(BorderFactory.createEmptyBorder(8, 32, 8, 32));
		
		alone.setIcon(radioIcon);
		alone.setSelectedIcon(radioSelectedIcon);
		withPeople.setIcon(radioIcon);
		withPeople.setSelectedIcon(radioSelectedIcon);
        alone.setIconTextGap(16);
		withPeople.setIconTextGap(16);
		
		ButtonGroup socialGroup = new ButtonGroup();
		socialGroup.add(alone);
		socialGroup.add(withPeople);
		socialPanel.add(alone);
		socialPanel.add(withPeople);
		
		socialBlock.add(socialPanel);
		contentPanel.add(socialBlock);
		
		// 퇴근 시간
		JPanel endTimeBlock = new JPanel();
        endTimeBlock.setLayout(new BoxLayout(endTimeBlock, BoxLayout.Y_AXIS));
        endTimeBlock.setOpaque(false);
		endTimeBlock.setBorder(new EmptyBorder(30, 0, 30, 0));
		
        JLabel endTimeLabel = new JLabel("오늘의 업무는 몇 시쯤 끝날 예정인가요?");
        endTimeLabel.setFont(new Font("Pretendard", Font.PLAIN, 26));
		endTimeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        endTimeBlock.add(endTimeLabel);
		
		endTimeBlock.add(Box.createVerticalStrut(15));
		
		JRadioButton endTimeAuto = new JRadioButton("자동 예측할래요");
        JRadioButton endTimeManual = new JRadioButton("직접 입력할래요");
        endTimeAuto.setFont(new Font("Pretendard", Font.PLAIN, 20));
        endTimeManual.setFont(new Font("Pretendard", Font.PLAIN, 20));
		
		ButtonGroup endTimeGroup = new ButtonGroup();
		endTimeGroup.add(endTimeAuto);
		endTimeGroup.add(endTimeManual);
		
		// 스타일 적용
		for (JRadioButton btn : new JRadioButton[]{endTimeAuto, endTimeManual}) {
			btn.setOpaque(false);	btn.setContentAreaFilled(false);	btn.setBorderPainted(false);
			btn.setIcon(radioIcon);
			btn.setSelectedIcon(radioSelectedIcon);
			btn.setIconTextGap(12);
			btn.setBorder(BorderFactory.createEmptyBorder(8, 20, 8, 20));
		}
		
		JPanel endTimeRadioPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
		endTimeRadioPanel.setOpaque(false);
        endTimeRadioPanel.add(endTimeAuto);
        endTimeRadioPanel.add(endTimeManual);
		
        String[] hours = new String[24];
        for (int i = 0; i < 24; i++) hours[i] = String.format("%02d", i);
        JComboBox<String> hourBox = new JComboBox<>(hours);
        hourBox.setPreferredSize(new Dimension(100, 40));
        hourBox.setEnabled(false);

        String[] minutes = new String[12];
        for (int i = 0; i < 12; i++) minutes[i] = String.format("%02d", i * 5);
        JComboBox<String> minuteBox = new JComboBox<>(minutes);
        minuteBox.setPreferredSize(new Dimension(100, 40));
        minuteBox.setEnabled(false);
		
		Font comboFont = new Font("Pretendard", Font.BOLD, 20);
		Color comboBg = new Color(255, 255, 255);
		Color comboFg = new Color(0x4E4E4E);
		
		hourBox.setFont(comboFont);
		hourBox.setBackground(comboBg);
		hourBox.setForeground(comboFg);
		minuteBox.setFont(comboFont);
		minuteBox.setBackground(comboBg);
		minuteBox.setForeground(comboFg);
		DefaultListCellRenderer centerRenderer = new DefaultListCellRenderer();
		centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
		hourBox.setRenderer(centerRenderer);
		minuteBox.setRenderer(centerRenderer);
		
        JLabel colonLabel = new JLabel(":");
		colonLabel.setFont(new Font("Pretendard", Font.BOLD, 24));
		endTimeRadioPanel.add(hourBox);
		endTimeRadioPanel.add(colonLabel);
		endTimeRadioPanel.add(minuteBox);
		
        endTimeBlock.add(endTimeRadioPanel);

        endTimeAuto.addActionListener(e -> {
            hourBox.setEnabled(false); minuteBox.setEnabled(false);
        });
        endTimeManual.addActionListener(e -> {
            hourBox.setEnabled(true); minuteBox.setEnabled(true);
        });
		
		contentPanel.add(endTimeBlock);
		
		// 입력 완료 버튼
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.setOpaque(false);
		JButton submitButton = new JButton("<html><center>입력 완료</center></html>");
        submitButton.setFont(new Font("Pretendard", Font.BOLD, 20));
		submitButton.setBackground(new Color(13, 39, 84));
		submitButton.setForeground(new Color(250, 240, 230));
        submitButton.setFocusPainted(false);
		submitButton.setPreferredSize(new Dimension(180, 50));
		buttonPanel.add(submitButton);
        buttonPanel.setBorder(new EmptyBorder(30, 0, 0, 0));
		contentPanel.add(buttonPanel, 0);  // 첫 번째 위치에 추가첫 번째 위치에 추가
		// 얼박사 (바로 위의 줄 282줄을 지우고, 바로 아래 줄 284줄을 붙이면 돼!)
		// contentPanel.add(buttonPanel);
		
        submitButton.addActionListener(e -> {
            // 1. 공통 데이터 수집
            String mood = verygood.isSelected() ? "😀" :
                    good.isSelected() ? "😊" :
                            average.isSelected() ? "😐" : "😞";

            int energy = energySlider.getValue() + 1; // 슬라이더 보정 (1~5)

            String companion = alone.isSelected() ? "혼자" : "함께";

            String endType = endTimeAuto.isSelected() ? "자동" : "수동";
            LocalTime endTime = null;
            String endTimeStr = null;

            if (endType.equals("수동")) {
                String hour = hourBox.getSelectedItem().toString().replace("시", "");
                String minute = minuteBox.getSelectedItem().toString().replace("분", "");
                endTimeStr = hour + ":" + minute;
                endTime = LocalTime.of(Integer.parseInt(hour), Integer.parseInt(minute));
            }

            UserStatus userStatus = new UserStatus(mood, energy, companion, endType, endTimeStr);

            // 2. 다음 화면 이동
            if (endType.equals("자동")) {
                new WorkStatusUI(userStatus).setVisible(true);
                dispose();
            } else {
                int response = JOptionPane.showConfirmDialog(
                        this,
                        "입력이 완료되었습니다.",
                        "확인",
                        JOptionPane.DEFAULT_OPTION,
                        JOptionPane.INFORMATION_MESSAGE
                );
                if (response == JOptionPane.OK_OPTION) {
                    new RoutineRecommendationUI(userStatus, endTime).setVisible(true); // ✅ 수정된 부분
                    dispose();
                }
            }
        });
        add(contentPanel, BorderLayout.CENTER);

        setVisible(true);
		
    }
	public class CustomSliderUI extends BasicSliderUI {
		public CustomSliderUI(JSlider slider) {
			super(slider);
		}
		
		@Override
		public void paintTrack(Graphics g) {
			Graphics2D g2 = (Graphics2D) g.create();
			g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
			
			int trackWidth = trackRect.width;
			int trackHeight = 20;
			int trackX = trackRect.x + (trackRect.width - trackWidth) / 2;
			int trackY = trackRect.y + (trackRect.height - trackHeight) / 2;
			
			// 배경 트랙(연한 회색)
			g2.setColor(new Color(220, 220, 220));
			g2.fillRoundRect(trackX, trackY, trackWidth, trackHeight, trackHeight, trackHeight);
			
			// 진행된 트랙(진한 색)
			int value = slider.getValue();
			int min = slider.getMinimum();
			int max = slider.getMaximum();
			int fillWidth = (int) ((value - min) * (trackWidth * 1.0 / (max - min)));
			g2.setColor(new Color(13, 39, 84)); // 검은색에 가까운 진한 색
			g2.fillRoundRect(trackX, trackY, fillWidth, trackHeight, trackHeight, trackHeight);
		}
		
		@Override
		public void paintThumb(Graphics g) {
			Graphics2D g2 = (Graphics2D) g;
			g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
			
			int thumbRadius = 20;
			int x = thumbRect.x + thumbRect.width / 2 - thumbRadius / 2;
			int y = thumbRect.y + thumbRect.height / 2 - thumbRadius / 2;
			
			g2.setColor(Color.WHITE); // 썸(동그리) 색상
			g2.fillOval(x, y, thumbRadius, thumbRadius);
			g2.setColor(new Color(13, 39, 84)); // 썸 테두리 색상
			g2.setStroke(new BasicStroke(2));
			g2.drawOval(x, y, thumbRadius, thumbRadius);
		}
		
		@Override
		protected Dimension getThumbSize() {
			return new Dimension(20, 20); // 썸(동그리) 크기
		}
	}

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new UserStatusUI());
    }	
}
