package model;

import java.io.Serializable;

public class UserStatus implements Serializable {
    private String mood;        // 🙂, 😊, 😐, 😞
    private int energy;         // 1~5
    private String companion;   // 혼자 / 함께
    private String endType;     // 자동 / 수동
    private String endTime;     // "18:30" (수동인 경우)

    public UserStatus(String mood, int energy, String companion, String endType, String endTime) {
        this.mood = mood;
        this.energy = energy;
        this.companion = companion;
        this.endType = endType;
        this.endTime = endTime;
    }

    // Getters
    public String getMood() { return mood; }
    public int getEnergy() { return energy; }
    public String getCompanion() { return companion; }
    public String getEndType() { return endType; }
    public String getEndTime() { return endTime; }

    // toString
    @Override
    public String toString() {
        return "UserStatus{" +
                "mood='" + mood + '\'' +
                ", energy=" + energy +
                ", companion='" + companion + '\'' +
                ", endType='" + endType + '\'' +
                ", endTime='" + endTime + '\'' +
                '}';
    }
}
