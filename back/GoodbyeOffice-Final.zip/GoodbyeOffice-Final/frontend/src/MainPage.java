import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class MainPage extends JFrame {

    public MainPage() {
        setTitle("GOODBYE OFFICE");

        // 전체 화면 설정
        Toolkit toolkit = Toolkit.getDefaultToolkit();
        Dimension screenSize = toolkit.getScreenSize();
        setSize(screenSize.width, screenSize.height);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(new Color(13, 39, 84));
        mainPanel.setLayout(null);
        add(mainPanel);

        JLabel titleLabel = new JLabel("GOODBYE-OFFICE", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Dialog", Font.BOLD, 48));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBounds(0, 60, screenSize.width, 60);
        mainPanel.add(titleLabel);

        JLabel serviceLabel = new JLabel(
            "<html><div style='text-align: center;'>오늘 하루, 어땠나요?<br>" +
            "간단한 입력만으로 퇴근 시간과 당신에게 꼭 맞는 마무리 루틴을 추천해드릴게요.</div></html>",
            SwingConstants.CENTER
        );
        serviceLabel.setFont(new Font("Dialog", Font.PLAIN, 20));
        serviceLabel.setForeground(Color.WHITE);
        serviceLabel.setBounds(0, 140, screenSize.width, 100);
        mainPanel.add(serviceLabel);

        // 버튼 컨테이너
        JPanel buttonBox = new JPanel();
        buttonBox.setBackground(new Color(13, 39, 84));
        buttonBox.setLayout(new GridLayout(1, 2, 60, 0));
        buttonBox.setBounds(screenSize.width / 2 - 250, 280, 500, 80);
        mainPanel.add(buttonBox);

        JButton userButton = new JButton("👤 사용자 시작하기");
        userButton.setFont(new Font("Dialog", Font.BOLD, 18));
        userButton.setBackground(Color.WHITE);
        userButton.setForeground(new Color(13, 39, 84));
        userButton.setFocusPainted(false);
        userButton.addActionListener(e -> {
            new LoginPage().setVisible(true); // 사용자 페이지로 이동
            dispose();
        });

        JButton adminButton = new JButton("🛠 관리자 로그인");
        adminButton.setFont(new Font("Dialog", Font.BOLD, 18));
        adminButton.setBackground(Color.WHITE);
        adminButton.setForeground(new Color(13, 39, 84));
        adminButton.setFocusPainted(false);
        adminButton.addActionListener(e -> {
            new AdminDashboardPage().setVisible(true); // 관리자 페이지로 이동
            dispose();
        });

        buttonBox.add(userButton);
        buttonBox.add(adminButton);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new MainPage().setVisible(true));
    }
}