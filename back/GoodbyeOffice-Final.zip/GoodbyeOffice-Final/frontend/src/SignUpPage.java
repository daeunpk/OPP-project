import javax.swing.*;
import java.awt.*;

public class SignUpPage extends JFrame {

    public SignUpPage() {
        setTitle("회원가입");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(new Color(13, 39, 84));

        JPanel mainPanel = new JPanel();
        mainPanel.setBackground(new Color(13, 39, 84));
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        add(mainPanel);

        mainPanel.add(Box.createVerticalGlue());

        JLabel title = new JLabel("회원가입 하기");
        title.setFont(new Font("맑은 고딕", Font.BOLD, 40)); // 폰트 키움
        title.setForeground(Color.WHITE);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        mainPanel.add(title);

        mainPanel.add(Box.createRigidArea(new Dimension(0, 40)));

        JPanel formWrapper = new JPanel();
        formWrapper.setBackground(new Color(13, 39, 84));
        formWrapper.setLayout(new BoxLayout(formWrapper, BoxLayout.X_AXIS));
        mainPanel.add(formWrapper);

        formWrapper.add(Box.createHorizontalGlue());

        JPanel formPanel = new JPanel(new GridLayout(5, 2, 25, 25)); // 간격 더 키움
        formPanel.setBackground(new Color(13, 39, 84));
        formPanel.setMaximumSize(new Dimension(900, 400));  // 더 크게
        formWrapper.add(formPanel);

        formWrapper.add(Box.createHorizontalGlue());

        mainPanel.add(Box.createVerticalGlue());

        String[] labels = {"이름", "나이", "주소", "이메일", "사번"};
        JTextField[] fields = new JTextField[labels.length];

        Font labelFont = new Font("맑은 고딕", Font.BOLD, 26); // 라벨 폰트 키우기
        Font fieldFont = new Font("맑은 고딕", Font.PLAIN, 24); // 텍스트필드 폰트 키우기

        for (int i = 0; i < labels.length; i++) {
            JLabel label = new JLabel(labels[i] + ":");
            label.setForeground(Color.WHITE);
            label.setHorizontalAlignment(SwingConstants.RIGHT);
            label.setFont(labelFont);
            formPanel.add(label);

            JTextField textField = new JTextField();
            textField.setFont(fieldFont);
            formPanel.add(textField);

            fields[i] = textField;
        }

        JButton completeBtn = new JButton("가입 완료");
        completeBtn.setBackground(Color.WHITE);
        completeBtn.setForeground(new Color(13, 39, 84));
        completeBtn.setFont(new Font("맑은 고딕", Font.BOLD, 28)); // 버튼도 키우기

        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(13, 39, 84));
        buttonPanel.add(completeBtn);
        buttonPanel.setMaximumSize(new Dimension(900, 80));  // 버튼 패널도 키움
        mainPanel.add(buttonPanel);

        completeBtn.addActionListener(e -> {
            System.out.println("회원가입 완료:");
            for (int i = 0; i < fields.length; i++) {
                System.out.println(labels[i] + ": " + fields[i].getText());
            }
            dispose();
            new LoginPage();
        });

        setVisible(true);
    }

    public static void main(String[] args) {
        new SignUpPage();
    }
}

