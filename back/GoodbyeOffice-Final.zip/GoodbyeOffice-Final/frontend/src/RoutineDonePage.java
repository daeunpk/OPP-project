import javax.swing.*;
import java.awt.*;

public class RoutineDonePage extends JFrame {

    public RoutineDonePage() {
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setTitle("전송 완료");
        setSize(500, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setBackground(new Color(29, 44, 107)); // 딥 네이비

        setLayout(new BorderLayout());

        // 상단 타이틀 바
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(new Color(29, 44, 107));
        topPanel.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.LIGHT_GRAY));

        JLabel titleLabel = new JLabel("GOODBYE-OFFICE");
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setFont(new Font("Dialog", Font.BOLD, 18));
        titleLabel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 0));
        topPanel.add(titleLabel, BorderLayout.WEST);
        add(topPanel, BorderLayout.NORTH);

        // 중앙 내용
        JPanel centerPanel = new JPanel();
        centerPanel.setBackground(new Color(29, 44, 107));
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));

        JLabel completeLabel = new JLabel("전송 완료!");
        completeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        completeLabel.setFont(new Font("Dialog", Font.BOLD, 24));
        completeLabel.setForeground(Color.WHITE);
        completeLabel.setBorder(BorderFactory.createEmptyBorder(40, 0, 20, 0));

        // 체크 아이콘 (흰색 원 안에 ✓)
        JLabel checkIcon = new JLabel("\u2713", SwingConstants.CENTER); // ✓
        checkIcon.setFont(new Font("Dialog", Font.BOLD, 40));
        checkIcon.setForeground(new Color(29, 44, 107));
        checkIcon.setOpaque(true);
        checkIcon.setBackground(Color.WHITE);
        checkIcon.setPreferredSize(new Dimension(80, 80));
        checkIcon.setMaximumSize(new Dimension(80, 80));
        checkIcon.setHorizontalAlignment(SwingConstants.CENTER);
        checkIcon.setVerticalAlignment(SwingConstants.CENTER);
        checkIcon.setAlignmentX(Component.CENTER_ALIGNMENT);
        checkIcon.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createEmptyBorder(20, 0, 20, 0),
                BorderFactory.createLineBorder(Color.WHITE, 1)
        ));
        checkIcon.setAlignmentY(Component.CENTER_ALIGNMENT);
        checkIcon.setHorizontalTextPosition(SwingConstants.CENTER);

        // 둥글게 만들기
        checkIcon.setBorder(BorderFactory.createLineBorder(Color.WHITE, 0));
        checkIcon.setOpaque(true);
        checkIcon.setBackground(Color.WHITE);

        // 메인 화면 버튼
        JButton backButton = new JButton("메인 화면");
        backButton.setFocusPainted(false);
        backButton.setBackground(Color.WHITE);
        backButton.setForeground(new Color(29, 44, 107));
        backButton.setFont(new Font("Dialog", Font.BOLD, 14));
        backButton.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        backButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        backButton.addActionListener(e -> {
            dispose();
            new MainPage().setVisible(true); // 메인 페이지로 이동
        });

        centerPanel.add(completeLabel);
        centerPanel.add(checkIcon);
        centerPanel.add(Box.createRigidArea(new Dimension(0, 20)));
        centerPanel.add(backButton);

        add(centerPanel, BorderLayout.CENTER);

        setVisible(true);
    }
}
