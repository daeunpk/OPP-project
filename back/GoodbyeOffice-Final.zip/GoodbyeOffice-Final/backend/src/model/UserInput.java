package model;

public class UserInput {
    public String mood;
    public String energy;
    public String social;
    public String leaveTime;
}