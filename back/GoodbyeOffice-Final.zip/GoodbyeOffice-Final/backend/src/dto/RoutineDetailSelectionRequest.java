package dto;

import java.util.List;

public class RoutineDetailSelectionRequest {
    public String routineName;
    public List<String> selectedItems;
}