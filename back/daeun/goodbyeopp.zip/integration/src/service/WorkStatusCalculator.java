package service;

import model.WorkStatus;
import java.time.LocalTime;

public class WorkStatusCalculator {

    public static LocalTime calculateEndTime(LocalTime baseTime, WorkStatus status) {
        int totalMinutes = 0;

        // 1. 남은 업무 개수 × 30분
        totalMinutes += status.getTaskCount() * 30;

        // 2. 업무 강도: 5 기준, ±1당 ±5% 적용
        double intensityMultiplier = 1.0 + ((status.getTaskIntensity() - 5) * 0.05);

        // 3. 회의
        if (status.isHasMeeting()) {
            totalMinutes += status.getMeetingCount() * 30;
        }

        // 4. 상사 기분 → 최대 20분 가산
        totalMinutes += getBossMoodPenalty(status.getBossMood());

        // 최종 반영 (강도 보정)
        int adjustedMinutes = (int) (totalMinutes * intensityMultiplier);

        return baseTime.plusMinutes(adjustedMinutes);
    }

    private static int getBossMoodPenalty(String mood) {
        switch (mood) {
            case "😀": return 0;
            case "😊": return 5;
            case "😐": return 10;
            case "😡": return 20;
            default: return 10; // 보통값
        }
    }
}
