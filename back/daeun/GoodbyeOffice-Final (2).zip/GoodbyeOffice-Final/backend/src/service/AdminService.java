package service;

import model.User;

import java.util.ArrayList;
import java.util.List;

public class AdminService {

    public List<User> getAllUsers() {
        // 실제로는 DB에서 가져오지만, 임시로 더미 데이터 반환
        List<User> users = new ArrayList<>();
        users.add(new User("user1", "pass1"));
        users.add(new User("user2", "pass2"));
        return users;
    }
}