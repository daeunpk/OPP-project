package model;

public class User {
    public String username;
    public String password;
}