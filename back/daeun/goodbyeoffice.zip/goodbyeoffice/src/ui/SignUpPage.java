import javax.swing.*;
import java.awt.*;
import service.*;
import model.*;

public class SignUpPage extends JFrame {


    public SignUpPage() {
        setTitle("GOODBYE-OFFICE");
		
        setExtendedState(JFrame.MAXIMIZED_BOTH); // 전체 화면
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(new Color(13, 39, 84));
		setLayout(null);
		
		int frameWidth = Toolkit.getDefaultToolkit().getScreenSize().width;
		int frameHeight = Toolkit.getDefaultToolkit().getScreenSize().height;
		
		// 상단 바
		JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBackground(new Color(13, 39, 84));
        topPanel.setBorder(BorderFactory.createMatteBorder(0, 0, 2, 0, new Color(250, 240, 230)));
		topPanel.setBounds(0, 0, frameWidth, 80);
		
        JLabel topTitleLabel = new JLabel("GOODBYE - OFFICE");
        topTitleLabel.setForeground(new Color(250, 240, 230));
        topTitleLabel.setFont(new Font("Pretendard", Font.BOLD, 26));
        topTitleLabel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 0));
        topPanel.add(topTitleLabel, BorderLayout.WEST);
		
		JButton homeButton = new JButton("\u2302");
		homeButton.setFont(new Font("Pretendard", Font.BOLD, 40));
		homeButton.setBackground(new Color(13, 39, 84));
		homeButton.setForeground(new Color(250, 240, 230));
		homeButton.setFocusPainted(false);
		homeButton.setBorder(BorderFactory.createEmptyBorder(5, 15, 5, 15));
		homeButton.addActionListener(e -> {
			new MainPage().setVisible(true);
			dispose();
		});
		topPanel.add(homeButton, BorderLayout.EAST);
        add(topPanel);
		
		// 제목 라벨
		JLabel titleLabel = new JLabel("회원가입");
        titleLabel.setFont(new Font("Pretendard", Font.BOLD, 40));
        titleLabel.setForeground(new Color(250, 240, 230));
        titleLabel.setBounds((frameWidth - 150) / 2, 220, 250, 60);
        add(titleLabel);
		
		// 입력 필드 배열 계산
		int fieldWidth = 300;
        int fieldHeight = 40;
        int labelWidth = 90;
        int startX = (frameWidth - (labelWidth + 10 + fieldWidth)) / 2;
        int startY = 330;
        int gap = 70;

        // 라벨 + 텍스트필드 배열로 구성
        String[] labels = {"이름", "나이", "주소", "이메일", "사번"};
        JTextField[] fields = new JTextField[labels.length];

        for (int i = 0; i < labels.length; i++) {
            JLabel label = new JLabel(labels[i] + ":");
			label.setFont(new Font("Pretendard", Font.BOLD, 24));
            label.setForeground(new Color(250, 240, 230));
            label.setBounds(startX, startY + i * gap, labelWidth, fieldHeight);
            add(label);

            JTextField textField = new JTextField();
			textField.setFont(new Font("Pretendard", Font.PLAIN, 18));
            textField.setBounds(startX + labelWidth + 10, startY + i * gap, fieldWidth, fieldHeight);
            add(textField);

            fields[i] = textField;
        }
		
		// 가입 완료 버튼
		int buttonWidth = 250;
		int buttonHeight = 50;
		int centerX = startX + (labelWidth + 10 + fieldWidth - buttonWidth) / 2;
		int buttonY = startY + labels.length * gap + 60;
		
		JButton completeBtn = new JButton("가입 완료");
		completeBtn.setFont(new Font("Pretendard", Font.BOLD, 18));
		completeBtn.setBackground(new Color(250, 240, 230));
		completeBtn.setForeground(new Color(13, 39, 84));
		completeBtn.setBounds(centerX, buttonY, buttonWidth, buttonHeight);
		add(completeBtn);

        UserService userService = UserService.getInstance();

        completeBtn.addActionListener(e -> {
            String name = fields[0].getText();
            String age = fields[1].getText();
            String address = fields[2].getText();
            String email = fields[3].getText();
            String empId = fields[4].getText();

            User user = new User(name, age, address, email, empId);
            if (userService.registerUser(user)) {
                JOptionPane.showMessageDialog(null, "회원가입 성공!");
                dispose();
                new LoginPage();
            } else {
                JOptionPane.showMessageDialog(null, "이미 존재하는 사번입니다.");
            }
        });


        setVisible(true);
    }
}
