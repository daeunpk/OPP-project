package model;

import java.io.Serializable;

/**
 * 사용자의 업무 상태를 저장하는 모델 클래스
 * - 퇴근 시간 예측 및 루틴 추천의 입력값으로 사용
 */
public class WorkStatus implements Serializable {

    private static final long serialVersionUID = 1L;

    private int taskCount;         // 남은 업무 개수
    private int taskIntensity;     // 업무 강도 (0 ~ 10)
    private boolean hasMeeting;    // 회의 있음/없음
    private int meetingCount;      // 회의 개수
    private String bossMood;       // 상사 기분 (😀, 😊, 😐, 😡)

    /**
     * 모든 필드를 받는 생성자
     */
    public WorkStatus(int taskCount, int taskIntensity, boolean hasMeeting, int meetingCount, String bossMood) {
        this.taskCount = taskCount;
        this.taskIntensity = taskIntensity;
        this.hasMeeting = hasMeeting;
        this.meetingCount = meetingCount;
        this.bossMood = bossMood;
    }

    // Getter 메서드들

    public int getTaskCount() {
        return taskCount;
    }

    public int getTaskIntensity() {
        return taskIntensity;
    }

    public boolean isHasMeeting() {
        return hasMeeting;
    }

    public int getMeetingCount() {
        return meetingCount;
    }

    public String getBossMood() {
        return bossMood;
    }

    /**
     * 업무 상태를 문자열로 요약 (디버깅, 로깅용)
     */
    @Override
    public String toString() {
        return String.format(
                "WorkStatus { 업무 개수 = %d, 강도 = %d, 회의 있음 = %b, 회의 수 = %d, 상사 기분 = '%s' }",
                taskCount, taskIntensity, hasMeeting, meetingCount, bossMood
        );
    }
}
