package model;

import java.util.List;

public class Routine {
    public String category;
    public List<String> suggestions;
}