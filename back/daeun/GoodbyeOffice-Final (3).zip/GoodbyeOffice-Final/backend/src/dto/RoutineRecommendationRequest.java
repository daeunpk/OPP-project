package dto;

public class RoutineRecommendationRequest {
    public String mood;
    public String energy;
}