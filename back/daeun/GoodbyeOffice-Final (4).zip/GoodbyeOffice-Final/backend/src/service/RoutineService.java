package service;

import model.Routine;

import java.util.ArrayList;
import java.util.List;

public class RoutineService {

    public List<Routine> recommendRoutines(String mood, String energy) {
        List<Routine> routines = new ArrayList<>();

        if ("happy".equalsIgnoreCase(mood) && "high".equalsIgnoreCase(energy)) {
            routines.add(new Routine("매운 음식", List.of("떡볶이", "마라탕", "불닭볶음면")));
            routines.add(new Routine("활동적인 루틴", List.of("야간 산책", "실내 자전거", "친구와 통화")));
        } else if ("sad".equalsIgnoreCase(mood) || "low".equalsIgnoreCase(energy)) {
            routines.add(new Routine("회복 루틴", List.of("반신욕", "명상", "좋아하는 음악 듣기")));
            routines.add(new Routine("편안한 식사", List.of("죽", "우동", "미역국")));
        } else {
            routines.add(new Routine("기본 루틴", List.of("독서", "일기쓰기", "가벼운 스트레칭")));
        }

        return routines;
    }
}