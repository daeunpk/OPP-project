package dto;

public class UserSignUpRequest {
    public String username;
    public String password;
}